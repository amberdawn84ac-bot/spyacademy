

import { Mission, Subject, SpellingList } from './types';

// --- CURRICULUM DATA ---

const CATEGORIES = {
  SYSTEM: "The System Behind the System (Weeks 1-2)",
  HEALTH: "Health & Medicine (Weeks 3-14)",
  FOOD: "Food, Agriculture & Environment (Weeks 15-24)",
  ECONOMY: "Economics & Poverty (Weeks 25-36)",
  GOVT: "Government, Power & Systems (Weeks 37-46)",
  TECH: "Technology & Modern Power (Weeks 47-54)",
  TRUTH: "Truth, Education & Closing the Loop (Weeks 55-60)"
};

export const CURRICULUM: Mission[] = [
  // WEEKS 1-2
  {
    id: "WK-01", 
    week: 1, 
    category: CATEGORIES.SYSTEM, 
    status: 'active',
    title: "Operation Regulatory Capture",
    subject: 'History', 
    credits: 0.1,
    description: "When corporations write the laws that are supposed to regulate them, democracy dies. We investigate ALEC and the 'Model Bill' machine.",
    content: `## Target Profile
**Entity:** American Legislative Exchange Council (ALEC) & Corporate Lobbyists
**Crime:** Subverting democracy by pre-writing laws for state legislators that benefit corporations at the expense of public health and safety.
**Motive:** Greed (*Besa* - unjust gain).

### Historical Context
Legislators used to write laws based on the needs of their constituents. In the 1970s, corporations organized to counter consumer protection movements, creating a system where "model legislation" is handed to busy politicians ready to sign.

### The Deception
They claim to promote "free markets" and "limited government." In reality, they use government power to limit liability for corporations and crush local regulations (preemption).

### The Fallout
*   **Environment:** Laws passed to prevent cities from banning plastic bags.
*   **Labor:** Laws passed to prevent local minimum wage increases.
*   **Justice:** "Stand Your Ground" laws proliferated nationwide.

### Operational Objectives (Action)
**Civic Action:** Identify a current "model bill" in your state legislature.
**Task:** Write a formal letter to your representative asking for the specific origin of the bill's text and demanding a public hearing on its corporate sponsorship.

### Intel Analysis (Scripture)
**Verse:** Micah 7:3 (NIV)
*"Both hands are skilled in doing evil; the ruler demands gifts, the judge accepts bribes, the powerful dictate what they desire—they all conspire together."*

**Word Study:**
*   **English:** Bribe / Gift
*   **Original (Hebrew):** *Shochad* (שׁוֹחַד)
*   **Meaning:** It isn't just money under the table; it refers to a gift that "blinds the clear-sighted." In the ancient context, it meant anything that caused a leader to look away from the truth of a case to favor the donor. It distorts *Mishpat* (true justice).`
  },
  {
    id: "WK-02", 
    week: 2, 
    category: CATEGORIES.SYSTEM, 
    status: 'locked',
    title: "Operation Settlement Theater",
    subject: 'History', 
    credits: 0.1,
    description: "Why do billionaires pay fines but never go to jail? We expose the 'Cost of Doing Business' loophole.",
    content: `## Target Profile
**Entity:** The Department of Justice (DOJ) & Major Banks/Corporations
**Crime:** Establishing a two-tiered justice system where the rich pay fines (using shareholder money) while the poor go to prison.
**Motive:** Preservation of Power / Aversion to Accountability.

### Historical Context
Before the doctrine of "Too Big to Jail" (Holder Memo, 1999), corporate executives were personally liable for crimes. Now, the corporation itself pleads guilty, pays a fine, and no individual is handcuffed.

### The Deception
The government announces a "Record Breaking Fine!" to look tough on crime. The corporation releases a statement saying they have "resolved the matter" without admitting wrongdoing.

### The Fallout
*   **Repeat Offenders:** Pfizer was fined $2.3B in 2009 for illegal marketing. They viewed it as an expense, not a punishment, and stock prices often *go up* after settlements because the uncertainty is over.
*   **Victims:** Communities destroyed by fraud or pollution rarely see that money; it goes into the general Treasury.

### Operational Objectives (Action)
**Civic Action:** Committee Formation.
**Task:** Draft a proposal for a "Corporate Death Penalty" law (charter revocation) for repeat offenders in your state to be presented to the State Attorney General's office.

### Intel Analysis (Scripture)
**Verse:** Amos 5:12 (ESV)
*"For I know how many are your transgressions and how great are your sins—you who afflict the righteous, who take a bribe, and turn aside the needy in the gate."*

**Word Study:**
*   **English:** Turn aside (the needy)
*   **Original (Hebrew):** *Natah* (נָטָה)
*   **Meaning:** To stretch out, spread out, or turn away. In a legal context (the "gate" was the courthouse), it means to physically push the poor out of the legal process. When justice can be bought via settlements, the poor are *natah*—pushed out of the realm of justice entirely.`
  },
  {
      id: "WK-03", 
      week: 3, 
      category: CATEGORIES.HEALTH, 
      status: 'locked',
      title: "Operation Hooked",
      subject: 'Science', 
      credits: 0.1,
      description: "The Sackler family made billions by marketing an opioid as non-addictive, sparking a plague that killed 500,000 Americans.",
      content: `## Target Profile
**Entity:** Purdue Pharma (The Sackler Family)
**Crime:** Mass marketing OxyContin as "safe" and "non-addictive" while knowing it was chemically identical to heroin in effect.
**Motive:** *Philargyria* (Love of Money).

### Historical Context
Pain was traditionally treated with caution. In the 90s, Purdue funded a "Pain is the 5th Vital Sign" campaign to pressure doctors into prescribing opioids for minor injuries.

### The Deception
They created a graph with a "fake timeline" showing addiction was rare (less than 1%). They invented the term "pseudo-addiction" to tell doctors that drug-seeking behavior was actually a sign the patient needed *more* drugs.

### The Fallout
*   **Death Toll:** Over 500,000 dead from overdoses.
*   **Social Fabric:** Foster care systems overwhelmed; workforce participation dropped in rural areas.

### Operational Objectives (Action)
**Civic Action:** Legislative Advocacy (The BLOCK Act).
**Task:** Lobby for legislation that prevents pharmaceutical companies from funding the medical boards that write prescribing guidelines. Conflict of interest elimination.

### Intel Analysis (Scripture)
**Verse:** 1 Timothy 6:10 (KJV)
*"For the love of money is the root of all evil: which while some coveted after, they have erred from the faith, and pierced themselves through with many sorrows."*

**Word Study:**
*   **English:** Love of money
*   **Original (Greek):** *Philargyria* (φιλαργυρία)
*   **Meaning:** *Philos* (Love/Affection) + *Argyros* (Silver). It isn't just using money; it is an affection for silver that replaces human affection. The Sacklers knew people were dying (piercing themselves with sorrows), but their *philargyria* made the profits more valuable than human life.`
  }
];

export const SPELLING_CURRICULUM: SpellingList[] = [
  // --- GRADE 6 ---
  {
    id: "SP-06-01", week: 1, gradeLevel: 6, title: "Rules of Order", subject: 'History', credits: 0.05, difficulty: 'Level 1',
    words: ["rules", "order", "leader", "public", "power", "system", "court", "judge", "fair", "legal"]
  },
  {
    id: "SP-06-02", week: 2, gradeLevel: 6, title: "Earth Systems", subject: 'Science', credits: 0.05, difficulty: 'Level 1',
    words: ["planet", "cycle", "rock", "water", "vapor", "climate", "layer", "crust", "mantle", "core"]
  },
  {
    id: "SP-06-03", week: 3, gradeLevel: 6, title: "Basic Trade", subject: 'English', credits: 0.05, difficulty: 'Level 1',
    words: ["buy", "sell", "cost", "save", "spend", "coin", "money", "bank", "value", "need"]
  },

  // --- GRADE 7 ---
  {
    id: "SP-07-01", week: 1, gradeLevel: 7, title: "Colonial Systems", subject: 'History', credits: 0.05, difficulty: 'Level 1',
    words: ["colony", "settle", "native", "trade", "route", "empire", "tax", "revolt", "act", "stamp"]
  },
  {
    id: "SP-07-02", week: 2, gradeLevel: 7, title: "Life Science", subject: 'Science', credits: 0.05, difficulty: 'Level 1',
    words: ["species", "adapt", "biome", "niche", "prey", "plant", "animal", "fungi", "trait", "gene"]
  },
  {
    id: "SP-07-03", week: 3, gradeLevel: 7, title: "Supply Chain", subject: 'English', credits: 0.05, difficulty: 'Level 1',
    words: ["demand", "supply", "goods", "labor", "wage", "boss", "worker", "strike", "union", "deal"]
  },

  // --- GRADE 8 ---
  {
    id: "SP-08-01", week: 1, gradeLevel: 8, title: "Revolutionary Ideas", subject: 'History', credits: 0.05, difficulty: 'Level 2',
    words: ["liberty", "patriot", "loyal", "treason", "battle", "declare", "united", "states", "rights", "peace"]
  },
  {
    id: "SP-08-02", week: 2, gradeLevel: 8, title: "Forces & Energy", subject: 'Science', credits: 0.05, difficulty: 'Level 2',
    words: ["motion", "speed", "force", "mass", "atom", "heat", "light", "sound", "wave", "pitch"]
  },
  {
    id: "SP-08-03", week: 3, gradeLevel: 8, title: "Market Forces", subject: 'English', credits: 0.05, difficulty: 'Level 2',
    words: ["profit", "loss", "invest", "share", "stock", "crash", "boom", "bust", "risk", "gain"]
  },

  // --- GRADE 9 (Freshman) ---
  {
    id: "SP-09-01", week: 1, gradeLevel: 9, title: "Foundations of Power", subject: 'History', credits: 0.05, difficulty: 'Level 1',
    words: ["citizen", "rights", "duty", "justice", "liberty", "freedom", "law", "vote", "elect", "govern"]
  },
  {
    id: "SP-09-02", week: 2, gradeLevel: 9, title: "Biological Basis", subject: 'Science', credits: 0.05, difficulty: 'Level 1',
    words: ["nucleus", "membrane", "cell", "tissue", "organ", "system", "life", "growth", "energy", "adapt"]
  },
  {
    id: "SP-09-03", week: 3, gradeLevel: 9, title: "Economic Basics", subject: 'English', credits: 0.05, difficulty: 'Level 1',
    words: ["trade", "barter", "goods", "service", "market", "price", "cost", "value", "profit", "debt"]
  },

  // --- GRADE 10 (Sophomore) ---
  {
    id: "SP-10-01", week: 1, gradeLevel: 10, title: "Civic Structures", subject: 'History', credits: 0.05, difficulty: 'Level 2',
    words: ["republic", "democracy", "monarchy", "dictator", "senate", "congress", "cabinet", "policy", "statute", "decree"]
  },
  {
    id: "SP-10-02", week: 2, gradeLevel: 10, title: "Chemical Reactions", subject: 'Science', credits: 0.05, difficulty: 'Level 2',
    words: ["atom", "electron", "proton", "neutron", "bond", "acid", "base", "metal", "gas", "solid"]
  },
  {
    id: "SP-10-03", week: 3, gradeLevel: 10, title: "Global Markets", subject: 'English', credits: 0.05, difficulty: 'Level 2',
    words: ["import", "export", "tariff", "quota", "currency", "exchange", "surplus", "deficit", "stock", "bond"]
  },

  // --- GRADE 11 (Junior) ---
  {
    id: "SP-11-01", week: 1, gradeLevel: 11, title: "Political Strategy", subject: 'History', credits: 0.05, difficulty: 'Level 2',
    words: ["partisan", "bipartisan", "coalition", "alliance", "treaty", "sanction", "diplomat", "embassy", "delegate", "primary"]
  },
  {
    id: "SP-11-02", week: 2, gradeLevel: 11, title: "Physics & Motion", subject: 'Science', credits: 0.05, difficulty: 'Level 2',
    words: ["velocity", "momentum", "inertia", "gravity", "friction", "vector", "force", "mass", "energy", "joule"]
  },
  {
    id: "SP-11-03", week: 3, gradeLevel: 11, title: "Corporate Finance", subject: 'English', credits: 0.05, difficulty: 'Level 2',
    words: ["dividend", "equity", "liability", "asset", "revenue", "fiscal", "audit", "merger", "monopoly", "subsidy"]
  },

  // --- GRADE 12 (Senior - Original Advanced Lists) ---
  {
    id: "SP-12-01", week: 1, gradeLevel: 12, title: "Lobbying & Influence", subject: 'English', credits: 0.05, difficulty: 'Level 3',
    words: ["legislation", "influence", "bureaucracy", "regulator", "corporate", "constituent", "bribery", "campaign", "incentive", "loophole"]
  },
  {
    id: "SP-12-02", week: 2, gradeLevel: 12, title: "Justice & Settlements", subject: 'English', credits: 0.05, difficulty: 'Level 3',
    words: ["plaintiff", "defendant", "litigation", "settlement", "negligence", "liability", "prosecutor", "verdict", "testimony", "evidence"]
  },
  {
    id: "SP-12-03", week: 3, gradeLevel: 12, title: "Pharma & Ethics", subject: 'English', credits: 0.05, difficulty: 'Level 3',
    words: ["epidemic", "prescription", "addiction", "narcotic", "marketing", "deceptive", "synthetic", "withdrawal", "overdose", "pharmacy"]
  },
  {
    id: "SP-12-04", week: 4, gradeLevel: 12, title: "Chemistry of Health", subject: 'English', credits: 0.05, difficulty: 'Level 3',
    words: ["molecule", "receptor", "organism", "cellular", "immunity", "pathogen", "vaccine", "diagnosis", "symptom", "treatment"]
  },
  {
    id: "SP-12-05", week: 5, gradeLevel: 12, title: "Agricultural Systems", subject: 'English', credits: 0.05, difficulty: 'Level 3',
    words: ["monoculture", "pesticide", "herbicide", "organic", "sustainable", "harvest", "fertilizer", "irrigation", "pollinator", "ecosystem"]
  }
];

// --- PUBLIC PAGE DATA ---

export const INITIAL_ART_PROJECTS = [
  {
    id: 1,
    title: "Natural Dyeing",
    subject: 'Arts' as Subject, credits: 0.2,
    image: "https://images.unsplash.com/photo-1596395353526-9f76a5933c09?q=80&w=2070&auto=format&fit=crop",
    wowFactor: "Turning plain white cloth into vibrant colors using kitchen scraps and wildflowers.",
    concepts: ["Extraction", "Mordants", "Absorption"],
    connection: "God clothes the lilies of the field. Nature is packed with hidden color waiting to be revealed.",
    materials: ["Marigolds or Onion Skins", "White Cotton or Wool", "Alum (Mordant)", "Large Pot"],
    instructions: [
        { title: "Preparation", steps: ["Simmer the plant material for 1 hour to extract the dye.", "Strain the liquid into a clean pot."] },
        { title: "The Process", steps: ["Add your mordanted cloth to the pot.", "Simmer gently for 30-60 minutes.", "Rinse with cold water and hang to dry."] }
    ],
    safety: ["Use a dedicated pot for dyeing (not for food).", "Liquid is hot."]
  },
  {
    id: 2,
    title: "Cyanotype Sun Prints",
    subject: 'Arts' as Subject, credits: 0.1,
    image: "https://images.unsplash.com/photo-1616429566374-724d2625c276?q=80&w=2071&auto=format&fit=crop",
    wowFactor: "Creating instant blue photographs using nothing but chemistry and sunlight.",
    concepts: ["Photochemistry", "UV Radiation", "Negative Space"],
    connection: "The heavens declare the glory of God. Light reveals truth and creates permanent impressions.",
    materials: ["Cyanotype Kit (Part A & B)", "Watercolor Paper", "Pressed Flowers", "Sunlight"],
    instructions: [
        { title: "Coating", steps: ["Mix Part A and B in a dark room.", "Paint the solution onto paper.", "Let it dry in the dark."] },
        { title: "Exposure", steps: ["Place plants on the paper.", "Expose to direct sunlight until bronze.", "Rinse in water until blue."] }
    ],
    safety: ["Wear gloves when mixing chemicals.", "Do not ingest."]
  },
  {
    id: 3,
    title: "Hammered Flower Prints",
    subject: 'Arts' as Subject, credits: 0.1,
    image: "https://images.unsplash.com/photo-1688636531388-7245c4779261?q=80&w=2070&auto=format&fit=crop",
    wowFactor: "Smashing flowers to transfer their perfect dye and intricate shape directly to cloth.",
    concepts: ["Pigment Transfer", "Botanical Structure", "Impact Force"],
    connection: "Beauty hidden inside brokenness. Sometimes pressure brings out the best in us.",
    materials: ["Fresh Flowers (Pansies work best)", "Hammer", "Watercolor Paper", "Paper Towel"],
    instructions: [
        { title: "Arrangement", steps: ["Place the flower face down on the paper.", "Cover carefully with a paper towel."] },
        { title: "Transfer", steps: ["Hammer firmly over the entire flower.", "Peel back the towel and stems to reveal the print."] }
    ],
    safety: ["Watch your fingers with the hammer.", "Use a stable surface."]
  },
  {
    id: 4,
    title: "Charcoal Making",
    subject: 'Arts' as Subject, credits: 0.2,
    image: "https://images.unsplash.com/photo-1617503752587-97d2103a96ea?q=80&w=1919&auto=format&fit=crop",
    wowFactor: "Making your own professional drawing tools from willow branches in a fire.",
    concepts: ["Pyrolysis", "Carbon Cycle", "Reduction"],
    connection: "Beauty from ashes. A process of restoration and refinement.",
    materials: ["Willow Sticks (peeled)", "Altoids Tin (with hole)", "Fire or Grill"],
    instructions: [
        { title: "Cooking", steps: ["Pack sticks tightly in the tin.", "Place the tin in the fire.", "Watch for gas burning from the hole."] },
        { title: "Creation", steps: ["When the smoke stops, remove and cool.", "Use the sticks to sketch."] }
    ],
    safety: ["Fire hazard.", "Tin gets extremely hot."]
  },
  {
    id: 5,
    title: "Scripture Illumination Cards",
    subject: 'Arts' as Subject, credits: 0.2,
    image: "https://images.unsplash.com/photo-1544816155-12df9643f363?q=80&w=2062&auto=format&fit=crop",
    wowFactor: "Illuminating sacred words with watercolor and garden botanicals to deepen memory and meditation.",
    concepts: ["Calligraphy", "Linguistics", "Mixed Media"],
    connection: "Writing Scripture writes it on our hearts. Beauty draws the eye to truth.",
    materials: ["Cardstock/Watercolor Paper", "Watercolor Paints", "Black Pen/Marker", "Pressed Flowers", "Glue Stick"],
    instructions: [
        { title: "Background", steps: ["Brush watercolor across the card.", "Splatter gold paint for sparkle if desired.", "Let dry completely (1 hour)."] },
        { title: "Inscription", steps: ["Practice writing the Hebrew (Right-to-Left) or Greek word.", "Write the word carefully in ink.", "Add the English translation and verse reference below."] },
        { title: "Illumination", steps: ["Arrange pressed flowers around the text.", "Glue gently in place.", "Add final gold accents."] }
    ],
    safety: ["Keep liquids away from finished pages.", "Handle pressed flowers delicately."]
  }
];

export const INITIAL_SCIENCE_EXPERIMENTS = [
  {
    id: 1,
    title: "Elephant Toothpaste",
    subject: 'Science' as Subject, credits: 0.1,
    image: "https://images.unsplash.com/photo-1576319155264-99536e0be1ee?q=80&w=2070&auto=format&fit=crop",
    wowFactor: "A massive foam explosion that shoots 3-6 feet in the air, creating a spectacular thermal reaction.",
    concepts: ["Decomposition", "Catalysts", "Exothermic Reactions"],
    connection: "Just as the enzyme catalase in your body breaks down toxins rapidly, this reaction reveals the hidden power of catalysts to accelerate change.",
    materials: ["1/2 cup 6% Hydrogen Peroxide", "Dish soap", "Food coloring", "1 packet Dry Yeast", "3 tbsp Warm Water", "16oz Plastic Bottle"],
    instructions: [
        { title: "The Setup", steps: ["Place the bottle in a deep tray or outside on the grass.", "Pour peroxide, a squirt of soap, and food coloring into the bottle.", "Swirl gently to mix."] },
        { title: "The Catalyst", steps: ["In a separate cup, mix the yeast with warm water for 30 seconds.", "Count down from three.", "Pour the yeast mixture into the bottle and STEP BACK quickly."] }
    ],
    safety: ["Goggles are mandatory.", "The foam is HOT (exothermic). Do not touch immediately.", "Do not swallow."]
  },
  {
    id: 2,
    title: "Mentos & Coke Rockets",
    subject: 'Science' as Subject, credits: 0.1,
    image: "https://images.unsplash.com/photo-1628155930542-411a0523f39c?q=80&w=2070&auto=format&fit=crop",
    wowFactor: "Bottles launching 20-50 feet into the air with a deafening swoosh.",
    concepts: ["Nucleation", "Pressure", "Propulsion"],
    connection: "Birds and insects use propulsion to navigate the skies—pushing air backward to move forward. Here we see physics in its most explosive form.",
    materials: ["2-liter Diet Coke", "Mentos mints (original)", "Launcher mechanism or String", "Open Field"],
    instructions: [
        { title: "Preparation", steps: ["Remove the cap from the soda.", "Drill a hole in the cap just large enough for the string."] },
        { title: "The Payload", steps: ["Thread a string through 5-7 Mentos.", "Carefully lower them into the bottle neck, holding them above the soda with the cap."] },
        { title: "Launch", steps: ["Screw the cap tight.", "Let go of the string so the mints fall.", "Run."] }
    ],
    safety: ["Outdoor use only.", "Maintain 20ft distance.", "Never point the bottle at anyone."]
  },
  {
    id: 3,
    title: "Dry Ice Fog & Screams",
    subject: 'Science' as Subject, credits: 0.1,
    image: "https://images.unsplash.com/photo-1605557626697-2e87166d88f9?q=80&w=2070&auto=format&fit=crop",
    wowFactor: "Eerie, heavy fog that sinks to the floor and metal that screams when touched.",
    concepts: ["Sublimation", "States of Matter", "Density"],
    connection: "Water usually melts, but CO2 sublimates. A reminder of the diverse physical laws God designed to govern different elements.",
    materials: ["Dry Ice", "Heavy Gloves/Tongs", "Warm Water", "Metal Spoon", "Bowl"],
    instructions: [
        { title: "The Cauldron", steps: ["Place dry ice chunks in a bowl.", "Pour warm water over them to create thick, sinking fog."] },
        { title: "The Scream", steps: ["Press a warm metal spoon firmly against a chunk of dry ice.", "Listen to the vibration caused by rapid sublimation."] }
    ],
    safety: ["NEVER touch dry ice with bare hands (Frostbite hazard).", "Use in a well-ventilated area.", "Do not seal in an airtight container."]
  },
  {
    id: 4,
    title: "Oobleck Pool",
    subject: 'Science' as Subject, credits: 0.1,
    image: "https://images.unsplash.com/photo-1558225577-c93d939e6a0d?q=80&w=1974&auto=format&fit=crop",
    wowFactor: "A fluid you can walk on, punch, and roll, but that turns to liquid when you stand still.",
    concepts: ["Non-Newtonian Fluids", "Shear Thickening", "Viscosity"],
    connection: "Like quicksand, this material defies our expectations of solid vs. liquid, adapting its state based on the force applied.",
    materials: ["Cornstarch", "Water", "Large Container", "Food Coloring"],
    instructions: [
        { title: "The Ratio", steps: ["Mix 2 parts cornstarch with 1 part water.", "Stir slowly until it feels like honey."] },
        { title: "The Test", steps: ["Punch the surface hard—it should feel solid.", "Rest your hand gently—it should sink like liquid."] }
    ],
    safety: ["Do not pour down the drain (it will clog).", "Very slippery if spilled on floor."]
  }
];

export const INITIAL_FARM_PROJECTS = [
  {
    id: 1,
    title: "20x60 Greenhouse Build",
    subject: 'Electives' as Subject, credits: 0.5,
    image: "https://images.unsplash.com/photo-1569880153113-76e33fc52bb3?q=80&w=2070&auto=format&fit=crop",
    wowFactor: "Creating 1,200 sq ft of protected grow space to insure food security through winter.",
    concepts: ["Structure", "Thermal Mass", "Aerodynamics"],
    connection: "Shelter is a divine provision. We steward the land by extending the seasons God gave us.",
    materials: ["1-5/8\" Chain link top rail", "6mil Greenhouse Plastic", "Wiggle Wire", "Ground Posts", "2x4 Lumber"],
    instructions: [
        { title: "Foundation", steps: ["Square the corners using the 3-4-5 triangle method.", "Drive ground posts every 4 feet.", "Level the perimeter baseboards."] },
        { title: "Framing", steps: ["Bend top rail pipes to form bows.", "Insert bows into ground posts.", "Install the center purlin for ridge stability."] },
        { title: "Covering", steps: ["Wait for a perfectly calm morning.", "Pull plastic over the frame.", "Secure with wiggle wire, starting at the peak."] }
    ],
    safety: ["Wind is the enemy during installation.", "Use safe ladder practices.", "Wear gloves when handling metal rails."]
  },
  {
    id: 2,
    title: "Hydroponic Garden System",
    subject: 'Science' as Subject, credits: 0.3,
    image: "https://images.unsplash.com/photo-1581578017093-cd30fce4eeb7?q=80&w=2070&auto=format&fit=crop",
    wowFactor: "Growing food 3x faster using 90% less water than traditional soil gardening.",
    concepts: ["Nutrient Film", "pH Balance", "Fluid Dynamics"],
    connection: "Efficiency in nature. Understanding exactly what a plant needs to thrive allows us to be better caretakers.",
    materials: ["4-inch PVC Pipe or Fence Post", "Submersible Pump", "27 gal Reservoir Tote", "Net Cups", "Clay Pebbles"],
    instructions: [
        { title: "Channels", steps: ["Drill 3-inch holes spaced 8 inches apart in the PVC.", "Mount channels with a slight slope (1/4 inch per foot)."] },
        { title: "Circulation", steps: ["Connect the pump in the reservoir to the top of the channels.", "Route drain lines back to the reservoir."] },
        { title: "Planting", steps: ["Place seedlings in net cups.", "Check pH daily (aim for 6.0).", "Watch them grow."] }
    ],
    safety: ["Keep electrical connections dry.", "Wash hands after handling concentrated nutrients."]
  },
  {
    id: 3,
    title: "Rocket Stove Mass Heater",
    subject: 'Electives' as Subject, credits: 0.3,
    image: "https://images.unsplash.com/photo-1510672981848-fa0c4bca23f9?q=80&w=2070&auto=format&fit=crop",
    wowFactor: "Burning mere twigs to heat a bench for 12 hours with zero smoke.",
    concepts: ["Thermodynamics", "Combustion", "Thermal Battery"],
    connection: "Maximum output from minimal input. Wisdom in energy usage reflects a heart of conservation.",
    materials: ["Fire Bricks", "55 gal Metal Barrel", "6-inch Stove Pipe", "Cob (Clay/Sand/Straw)", "Perlite"],
    instructions: [
        { title: " The Core", steps: ["Build a 'J' tube with fire bricks.", "Insulate the riser with perlite.", "Place the metal barrel over the riser."] },
        { title: "The Mass", steps: ["Route exhaust pipe horizontally through a bench made of cob.", "The mass absorbs heat to release slowly."] }
    ],
    safety: ["Carbon Monoxide detector is mandatory.", "Burn the barrel outside first to strip paint."]
  },
  {
    id: 4,
    title: "Rainwater Catchment",
    subject: 'Electives' as Subject, credits: 0.2,
    image: "https://images.unsplash.com/photo-1582294622560-605886a51d4b?q=80&w=1974&auto=format&fit=crop",
    wowFactor: "Harvesting 600 gallons of water from just 1 inch of rain on a small roof.",
    concepts: ["Gravity Feed", "Filtration", "Hydrostatic Pressure"],
    connection: "Provision from above. Preparing for the dry seasons is a biblical principle of wisdom.",
    materials: ["275 gal IBC Tote", "Gutters", "First Flush Diverter", "PVC Piping", "Screen Filters"],
    instructions: [
        { title: "Collection", steps: ["Install gutters on the roof.", "Route the downspout to a first-flush diverter to clean the water."] },
        { title: "Storage", steps: ["Level the ground for the tank (water is heavy!).", "Connect the input.", "Install an overflow pipe."] }
    ],
    safety: ["Cover all openings to prevent mosquitoes.", "Secure tank to prevent tipping.", "Water is non-potable without purification."]
  }
];

export const MOCK_STUDENTS: any[] = [
  { 
    id: 'agent-007', 
    username: 'jb007', 
    name: 'James Bond', 
    role: 'student',
    grade: 12,
    progress: {
        completedMissionIds: ['WK-01', 'WK-02', 'WK-03', 'WK-04', 'WK-05'],
        completedProjectIds: [1, 2], // Mock project completions
        completedSpellingIds: [],
        portfolioItems: {}
    }
  },
  { 
    id: 'agent-006', 
    username: '006', 
    name: 'Alec Trevelyan', 
    role: 'student',
    grade: 11,
    progress: {
        completedMissionIds: ['WK-01'],
        completedProjectIds: [],
        completedSpellingIds: [],
        portfolioItems: {}
    }
  },
   { 
    id: 'agent-q', 
    username: 'q', 
    name: 'Q', 
    role: 'student',
    grade: 10,
    progress: {
        completedMissionIds: ['WK-01', 'WK-02', 'WK-03', 'WK-04', 'WK-05', 'WK-06', 'WK-07', 'WK-08', 'WK-09', 'WK-10'],
        completedProjectIds: [1, 2, 3],
        completedSpellingIds: [],
        portfolioItems: {}
    }
  },
];
