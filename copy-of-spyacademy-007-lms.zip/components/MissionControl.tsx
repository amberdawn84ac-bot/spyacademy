
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { Mission, Project, User } from '../types';
import { GoogleGenAI } from "@google/genai";
import { Send, CheckCircle, Lock, ChevronDown, ChevronRight, FileUp, Search, Loader2, Edit, Plus, Briefcase, FlaskConical, Palette, Sprout, ShieldAlert, Mic, MicOff, Activity, Volume2 } from 'lucide-react';
import { connectSecureLine } from '../services/geminiService';

interface MissionControlProps {
  missions: Mission[];
  artProjects: Project[];
  scienceExperiments: Project[];
  farmProjects: Project[];
  user: User;
  completedMissionIds: string[];
  onCompleteMission: (id: string) => void;
  onUploadPortfolio: (missionId: string) => void;
  onUpdateMissions: (missions: Mission[]) => void;
  onUpdateArt: (projects: Project[]) => void;
  onUpdateScience: (projects: Project[]) => void;
  onUpdateFarm: (projects: Project[]) => void;
}

const DEFAULT_CHIEF_IMAGE = "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?q=80&w=1887&auto=format&fit=crop";
const ARCHITECT_IMAGE = "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=1888&auto=format&fit=crop";

type ContentType = 'mission' | 'science' | 'art' | 'farm';
type ContentItem = Mission | Project;

export const MissionControl: React.FC<MissionControlProps> = ({ 
    missions, artProjects, scienceExperiments, farmProjects,
    user, completedMissionIds, 
    onCompleteMission, onUploadPortfolio,
    onUpdateMissions, onUpdateArt, onUpdateScience, onUpdateFarm
}) => {
  const [activeType, setActiveType] = useState<ContentType>('mission');
  
  // Dynamic Content Selection
  const currentList = useMemo(() => {
      switch(activeType) {
          case 'mission': return missions;
          case 'science': return scienceExperiments;
          case 'art': return artProjects;
          case 'farm': return farmProjects;
          default: return missions;
      }
  }, [activeType, missions, artProjects, scienceExperiments, farmProjects]);

  // Use generic ID for selection
  const [selectedItemId, setSelectedItemId] = useState<string | number | null>(currentList.length > 0 ? currentList[0].id : null);
  const selectedItem = useMemo(() => currentList.find(i => i.id == selectedItemId) || null, [selectedItemId, currentList]);

  // Chat State
  const [chatHistory, setChatHistory] = useState<{role: 'user' | 'model', text: string}[]>([]);
  const [chatInput, setChatInput] = useState('');
  const [isChatLoading, setIsChatLoading] = useState(false);
  const chatContainerRef = useRef<HTMLDivElement>(null);
  
  // --- VOICE STATE ---
  const [isVoiceActive, setIsVoiceActive] = useState(false);
  const [voiceVolume, setVoiceVolume] = useState(0);
  const audioContextRef = useRef<AudioContext | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const inputSourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const closeConnectionRef = useRef<(() => void) | null>(null);

  // UI State
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({});
  const [searchQuery, setSearchQuery] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  
  // Generic Edit Form
  const [editForm, setEditForm] = useState<any>({});

  const isAdmin = user.role === 'admin';

  // Grouping logic
  const groupedContent = useMemo(() => {
    const groups: Record<string, ContentItem[]> = {};
    const query = searchQuery.toLowerCase();
    
    currentList.filter(item => 
        item.title.toLowerCase().includes(query) || 
        (item as Mission).category?.toLowerCase().includes(query)
    ).forEach(item => {
        const cat = (item as Mission).category || 'Main Index';
        if (!groups[cat]) groups[cat] = [];
        groups[cat].push(item);
    });
    return groups;
  }, [currentList, searchQuery]);

  // Reset chat/voice when item or type changes
  useEffect(() => {
    // If voice was active, disconnect it to avoid context confusion
    if (isVoiceActive) {
        handleVoiceDisconnect();
    }

    if (selectedItem) {
        if (isAdmin) {
             setChatHistory([{
                role: 'model',
                text: `ARCHITECT ONLINE. Accessing ${activeType.toUpperCase()} database. Selected: "${selectedItem.title}". \n\nI am calibrated to the new curriculum protocols. How shall we proceed?`
            }]);
        } else {
             setChatHistory([{
                role: 'model',
                text: `Agent ${user.name.split(' ')[0] || '007'}, this is M. Briefing for "${selectedItem.title}" loaded. Review the dossier. Do you have questions?`
            }]);
        }
    }
  }, [selectedItem, user.name, activeType, isAdmin]);

  // Auto-speak new AI messages (unless voice mode is active, which handles its own audio)
  useEffect(() => {
    const lastMsg = chatHistory[chatHistory.length - 1];
    // Only speak if it's a model message, not voice mode (voice mode uses Live API audio), and not the initial greeting (optional)
    if (lastMsg && lastMsg.role === 'model' && !isVoiceActive) {
        // Simple check to avoid speaking the initial load message if desirable, 
        // but user requested "read its messages out loud", so we speak everything.
        speakText(lastMsg.text);
    }
  }, [chatHistory]);

  // Scroll Chat
  useEffect(() => {
    if (chatContainerRef.current) {
        chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [chatHistory, isChatLoading]);

  // --- TTS LOGIC ---
  const speakText = (text: string) => {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    
    // Attempt to select a better voice
    const voices = window.speechSynthesis.getVoices();
    // Prefer Google UK English Male or similar authoritative voices if available
    const preferredVoice = voices.find(v => v.name.includes('Google UK English Male') || v.name.includes('Daniel')) || voices[0];
    if (preferredVoice) utterance.voice = preferredVoice;
    
    utterance.rate = 1.0;
    utterance.pitch = 0.9;
    window.speechSynthesis.speak(utterance);
  };

  // --- VOICE LOGIC ---
  const getAudioContext = () => {
    if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    }
    return audioContextRef.current;
  };

  const handleVoiceDisconnect = () => {
    if (closeConnectionRef.current) closeConnectionRef.current();
    if (streamRef.current) streamRef.current.getTracks().forEach(t => t.stop());
    if (processorRef.current) processorRef.current.disconnect();
    if (inputSourceRef.current) inputSourceRef.current.disconnect();
    
    setIsVoiceActive(false);
    setVoiceVolume(0);
  };

  const playAudioResponse = (arrayBuffer: ArrayBuffer) => {
      const ctx = getAudioContext();
      const dataView = new DataView(arrayBuffer);
      const float32 = new Float32Array(arrayBuffer.byteLength / 2);
      for (let i = 0; i < float32.length; i++) {
        float32[i] = dataView.getInt16(i * 2, true) / 32768.0;
      }

      const audioBuffer = ctx.createBuffer(1, float32.length, 24000);
      audioBuffer.getChannelData(0).set(float32);

      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(ctx.destination);
      
      const startTime = Math.max(ctx.currentTime, nextStartTimeRef.current);
      source.start(startTime);
      nextStartTimeRef.current = startTime + audioBuffer.duration;
  };

  const toggleVoice = async () => {
      if (isVoiceActive) {
          handleVoiceDisconnect();
          return;
      }

      if (!selectedItem) return;

      try {
          const ctx = getAudioContext();
          if (ctx.state === 'suspended') await ctx.resume();

          const stream = await navigator.mediaDevices.getUserMedia({ audio: { sampleRate: 16000, channelCount: 1, echoCancellation: true } });
          streamRef.current = stream;

          // Build context-aware prompt
          const contentText = activeType === 'mission' 
              ? (selectedItem as Mission).content 
              : `Project: ${(selectedItem as Project).title}. Description: ${(selectedItem as Project).wowFactor}`;
          
          const roleDesc = isAdmin 
            ? "You are The Architect, an advanced curriculum developer. You are discussing the selected content with the Admin. Help them edit or expand it."
            : "You are 'M', the Chief of Intelligence. Brief the agent on the mission content provided. Be stern, professional, but helpful.";
            
          const systemInstruction = `${roleDesc}\n\nCurrent File: "${selectedItem.title}"\nFile Data: ${contentText}\n\nProtocol: Voice conversation. Keep answers spoken, brief, and punchy. Over.`;

          const sessionPromise = connectSecureLine(
              (buffer) => playAudioResponse(buffer),
              () => handleVoiceDisconnect(),
              systemInstruction
          );

          // Setup Input
          const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
          const source = inputCtx.createMediaStreamSource(stream);
          const processor = inputCtx.createScriptProcessor(4096, 1, 1);

          processor.onaudioprocess = (e) => {
            const inputData = e.inputBuffer.getChannelData(0);
            
            // Visualizer
            let sum = 0;
            for(let i = 0; i < inputData.length; i++) sum += inputData[i] * inputData[i];
            setVoiceVolume(Math.sqrt(sum / inputData.length));

            const l = inputData.length;
            const int16 = new Int16Array(l);
            for (let i = 0; i < l; i++) {
                int16[i] = inputData[i] * 32768;
            }
            
            let binary = '';
            const bytes = new Uint8Array(int16.buffer);
            const len = bytes.byteLength;
            for (let i = 0; i < len; i++) {
                binary += String.fromCharCode(bytes[i]);
            }
            const b64 = btoa(binary);

            sessionPromise.then(session => {
                session.sendRealtimeInput({
                    media: { mimeType: 'audio/pcm;rate=16000', data: b64 }
                });
            });
          };

          source.connect(processor);
          processor.connect(inputCtx.destination);
          inputSourceRef.current = source;
          processorRef.current = processor;

          const session = await sessionPromise;
          closeConnectionRef.current = () => session.close();
          
          // Trigger initial greeting so the user knows the connection is live
          await session.send({ 
              parts: [{ text: "The Secure Voice Uplink is established. Please greet the agent briefly and ask for their report." }], 
              turnComplete: true 
          });

          setIsVoiceActive(true);
          nextStartTimeRef.current = ctx.currentTime;

      } catch (err) {
          console.error("Voice Error", err);
          alert("Secure Voice Uplink Failed. Check permissions and API Key.");
          setIsVoiceActive(false);
      }
  };

  // --- TEXT CHAT LOGIC ---
  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || !selectedItem) return;

    const userMsg = chatInput;
    setChatInput('');
    setChatHistory(prev => [...prev, {role: 'user', text: userMsg}]);
    setIsChatLoading(true);

    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const history = chatHistory.map(msg => ({ role: msg.role, parts: [{ text: msg.text }] }));

        let systemInstruction = "";
        if (isAdmin) {
            systemInstruction = `You are 'The Architect', an advanced AI curriculum developer... Current Item: ${JSON.stringify(selectedItem)}.`;
        } else {
            systemInstruction = `You are 'M', the spy agency chief... Content: ${JSON.stringify(selectedItem)}.`;
        }

        const chat = ai.chats.create({
            model: 'gemini-2.5-flash',
            history: history,
            config: { systemInstruction }
        });

        const result = await chat.sendMessage({ message: userMsg });
        const responseText = result.text || "(No audio or text response)";
        
        setChatHistory(prev => [...prev, {role: 'model', text: responseText}]);

    } catch (err) {
        console.error(err);
        setChatHistory(prev => [...prev, {role: 'model', text: "Secure line error. Unable to reach HQ."}]);
    } finally {
        setIsChatLoading(false);
    }
  };

  // --- CONTENT RENDERERS ---
  const toggleCategory = (cat: string) => {
    setExpandedCategories(prev => ({...prev, [cat]: !prev[cat]}));
  };

  const isCompleted = (id: string | number) => completedMissionIds.includes(String(id));

  const startEdit = (item: ContentItem) => {
      setEditForm(JSON.parse(JSON.stringify(item))); 
      setIsEditing(true);
  };
  
  const startCreate = () => {
      const base = {
          id: activeType === 'mission' ? `WK-${missions.length + 1}` : Date.now(),
          title: "New Entry",
          subject: 'Electives',
          credits: 0.1
      };

      if (activeType === 'mission') {
          setEditForm({
              ...base,
              week: missions.length + 1,
              category: "New Category",
              status: 'locked',
              description: "Brief summary...",
              content: `## Target Profile\n...`
          });
      } else {
          setEditForm({
              ...base,
              image: "",
              wowFactor: "",
              concepts: [],
              connection: "",
              materials: [],
              instructions: [],
              safety: []
          });
      }
      setIsEditing(true);
  }

  const saveItem = () => {
      if (!editForm.id || !editForm.title) return;
      const updateList = (prevList: any[], updater: (list: any[]) => void) => {
          const newList = [...prevList];
          const idx = newList.findIndex(i => i.id == editForm.id);
          if (idx >= 0) newList[idx] = editForm;
          else newList.push(editForm);
          updater(newList);
      };

      switch(activeType) {
          case 'mission': updateList(missions, onUpdateMissions); break;
          case 'art': updateList(artProjects, onUpdateArt); break;
          case 'science': updateList(scienceExperiments, onUpdateScience); break;
          case 'farm': updateList(farmProjects, onUpdateFarm); break;
      }
      setIsEditing(false);
      setSelectedItemId(editForm.id);
  };

  const renderDetailContent = () => {
      if (!selectedItem) return null;
      if (activeType === 'mission') {
          const m = selectedItem as Mission;
          return (
              <div className="prose prose-invert prose-sm prose-emerald">
                  {m.content.split('\n').map((line, i) => <p key={i} className="mb-2 whitespace-pre-wrap">{line}</p>)}
              </div>
          );
      } else {
          const p = selectedItem as Project;
          return (
              <div className="space-y-6 text-slate-300">
                  <div className="aspect-video rounded-lg overflow-hidden bg-black border border-slate-700">
                      {p.image && <img src={p.image} alt={p.title} className="w-full h-full object-cover" />}
                  </div>
                  <div>
                      <h4 className="text-emerald-500 font-bold uppercase text-xs tracking-widest mb-2">Overview</h4>
                      <p>{p.wowFactor}</p>
                  </div>
                  <div>
                      <h4 className="text-emerald-500 font-bold uppercase text-xs tracking-widest mb-2">Instructions</h4>
                      {p.instructions.map((step, i) => (
                          <div key={i} className="mb-4">
                              <div className="font-bold text-white mb-1">{step.title}</div>
                              <ul className="list-decimal list-inside text-sm space-y-1 text-slate-400">
                                  {step.steps.map((s, j) => <li key={j}>{s}</li>)}
                              </ul>
                          </div>
                      ))}
                  </div>
                  <div>
                      <h4 className="text-emerald-500 font-bold uppercase text-xs tracking-widest mb-2">Materials</h4>
                      <div className="flex flex-wrap gap-2">
                          {p.materials.map((m, i) => (
                              <span key={i} className="bg-slate-800 text-slate-300 px-2 py-1 rounded text-xs">{m}</span>
                          ))}
                      </div>
                  </div>
              </div>
          );
      }
  };

  const renderEditForm = () => {
     return (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="text-xs text-slate-500 uppercase">Title</label>
                    <input className="w-full bg-slate-900 border border-slate-800 p-2 rounded text-white" value={editForm.title} onChange={e => setEditForm({...editForm, title: e.target.value})} />
                </div>
                <div>
                    <label className="text-xs text-slate-500 uppercase">Subject</label>
                    <input className="w-full bg-slate-900 border border-slate-800 p-2 rounded text-white" value={editForm.subject} onChange={e => setEditForm({...editForm, subject: e.target.value})} />
                </div>
            </div>
            {activeType === 'mission' ? (
                 <textarea className="w-full bg-slate-900 border border-slate-800 p-2 rounded text-white h-96 font-mono text-xs leading-relaxed" value={editForm.content} onChange={e => setEditForm({...editForm, content: e.target.value})} />
            ) : (
                 <textarea className="w-full bg-slate-900 border border-slate-800 p-2 rounded text-white h-20" value={editForm.wowFactor} onChange={e => setEditForm({...editForm, wowFactor: e.target.value})} />
            )}
          </div>
     );
  };

  return (
    <div className="flex h-full gap-6 relative">
      {/* SIDEBAR NAVIGATION */}
      <div className="w-1/3 flex flex-col">
        {/* Type Selector Tabs */}
        <div className="flex mb-4 bg-slate-900 rounded-lg p-1 border border-slate-800">
            {[
                { id: 'mission', icon: Briefcase, label: 'Ops' },
                { id: 'science', icon: FlaskConical, label: 'R&D' },
                { id: 'art', icon: Palette, label: 'Arts' },
                { id: 'farm', icon: Sprout, label: 'Farm' },
            ].map(tab => (
                <button
                    key={tab.id}
                    onClick={() => { setActiveType(tab.id as ContentType); setSelectedItemId(null); }}
                    className={`flex-1 flex flex-col items-center justify-center py-2 rounded text-[10px] font-bold uppercase transition-all ${
                        activeType === tab.id 
                        ? 'bg-emerald-600 text-white shadow-lg' 
                        : 'text-slate-500 hover:text-white'
                    }`}
                >
                    <tab.icon className="w-4 h-4 mb-1" />
                    {tab.label}
                </button>
            ))}
        </div>

        <div className="flex items-center justify-between mb-4 border-b border-emerald-900 pb-2">
            <h2 className="text-lg font-mono text-emerald-400">Database Index</h2>
            {isAdmin && (
                <button onClick={startCreate} className="p-1 bg-emerald-900/50 hover:bg-emerald-500 text-emerald-400 hover:text-white rounded transition-colors">
                    <Plus className="w-4 h-4" />
                </button>
            )}
        </div>
        
        {/* Search */}
        <div className="mb-4 relative">
            <input
                type="text"
                placeholder="Search database..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg py-2 pl-9 pr-4 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-colors"
            />
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
        </div>

        {/* List */}
        <div className="overflow-y-auto pr-2 space-y-4 custom-scrollbar flex-1">
            {Object.keys(groupedContent).length === 0 && (
                <div className="text-center p-4 text-slate-600 text-xs italic">
                    No entries found.
                </div>
            )}

            {(Object.entries(groupedContent) as [string, ContentItem[]][]).map(([category, items]) => (
                <div key={category} className="border border-slate-800 rounded bg-slate-950/50">
                    <button 
                        onClick={() => toggleCategory(category)}
                        className="w-full flex items-center justify-between p-3 text-xs font-bold text-slate-300 hover:bg-slate-900 transition-colors uppercase tracking-wider"
                    >
                        <span>{category}</span>
                        {(expandedCategories[category] || searchQuery.length > 0) ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                    </button>
                    
                    {(expandedCategories[category] || searchQuery.length > 0) && (
                        <div className="divide-y divide-slate-800/50">
                            {items.map((item) => {
                                const completed = isCompleted(item.id);
                                const isSelected = selectedItemId == item.id;
                                
                                return (
                                    <div
                                        key={item.id}
                                        onClick={() => setSelectedItemId(item.id)}
                                        className={`p-4 cursor-pointer transition-all border-l-4 ${
                                            isSelected
                                                ? 'bg-emerald-900/20 border-emerald-500 text-emerald-100'
                                                : completed 
                                                    ? 'bg-slate-900 border-emerald-800 text-slate-400 opacity-75' 
                                                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800'
                                        }`}
                                    >
                                        <div className="flex justify-between items-center mb-1">
                                            <span className="font-mono text-[10px] text-emerald-600">ID: {item.id}</span>
                                            <div className="flex items-center space-x-2">
                                                {completed ? (
                                                    <CheckCircle className="w-3 h-3 text-emerald-500" />
                                                ) : (
                                                    <span className="text-[10px] bg-amber-500/10 text-amber-500 px-1 rounded">ACTIVE</span>
                                                )}
                                            </div>
                                        </div>
                                        <h3 className="text-sm font-bold truncate">{item.title}</h3>
                                    </div>
                                );
                            })}
                        </div>
                    )}
                </div>
            ))}
        </div>
      </div>

      {/* DETAIL AREA (Split View) */}
      <div className="w-2/3 flex gap-6">
        {/* Left Col: Chat/Voice */}
        <div className="w-1/2 flex flex-col bg-slate-950 rounded-xl border border-slate-800 overflow-hidden shadow-2xl relative">
            {/* Chat Header */}
            <div className="bg-slate-900 p-4 border-b border-slate-800 flex items-center justify-between">
                <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 rounded-full bg-slate-800 overflow-hidden border border-slate-600">
                        <img src={isAdmin ? ARCHITECT_IMAGE : DEFAULT_CHIEF_IMAGE} className="w-full h-full object-cover" alt="Chief" />
                    </div>
                    <div>
                        <h3 className="text-white font-bold text-sm">{isAdmin ? 'THE ARCHITECT' : 'M'}</h3>
                        <div className={`text-xs font-mono flex items-center ${isVoiceActive ? 'text-red-500' : 'text-emerald-500'}`}>
                            <span className={`w-2 h-2 rounded-full mr-2 ${isVoiceActive ? 'bg-red-500 animate-ping' : 'bg-emerald-500 animate-pulse'}`}></span>
                            {isVoiceActive ? 'VOICE UPLINK ACTIVE' : 'SECURE_UPLINK'}
                        </div>
                    </div>
                </div>
                
                {/* Voice Toggle */}
                <button
                    onClick={toggleVoice}
                    className={`p-3 rounded-full transition-all ${
                        isVoiceActive 
                        ? 'bg-red-500/20 text-red-500 border border-red-500/50 hover:bg-red-500/30' 
                        : 'bg-slate-800 text-slate-400 border border-slate-700 hover:text-emerald-500 hover:border-emerald-500'
                    }`}
                    title={isVoiceActive ? "Disconnect Voice" : "Connect Secure Voice"}
                >
                    {isVoiceActive ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                </button>
            </div>
            
            {/* Messages or Voice Visualizer */}
            {isVoiceActive ? (
                <div className="flex-1 flex flex-col items-center justify-center p-6 space-y-6 bg-slate-950">
                     <div className="relative">
                         <div className="absolute inset-0 bg-red-500/20 rounded-full blur-xl animate-pulse"></div>
                         <Activity className="w-24 h-24 text-red-500 relative z-10" style={{ transform: `scale(${1 + voiceVolume * 3})` }} />
                     </div>
                     <div className="text-center">
                         <h3 className="text-red-500 font-bold tracking-widest text-lg mb-2">LIVE AUDIO FEED</h3>
                         <p className="text-slate-500 text-xs font-mono">Speak clearly to verify clearance code.</p>
                         <div className="mt-4 flex gap-1 justify-center h-8 items-end">
                            {[1,2,3,4,5].map(i => (
                                <div key={i} className="w-1 bg-red-500/50" style={{ height: `${Math.max(10, voiceVolume * 100 * Math.random())}%` }}></div>
                            ))}
                         </div>
                     </div>
                </div>
            ) : (
                <div className="flex-1 overflow-y-auto p-4 space-y-4 scroll-smooth" ref={chatContainerRef}>
                    {chatHistory.map((msg, i) => (
                        <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                            <div className={`max-w-[90%] p-3 rounded-lg text-xs md:text-sm leading-relaxed relative group ${
                                msg.role === 'user' 
                                ? 'bg-emerald-900/30 text-emerald-100 border border-emerald-500/30 rounded-tr-none' 
                                : 'bg-slate-800 text-slate-300 border border-slate-700 rounded-tl-none'
                            }`}>
                                {msg.text}
                                {msg.role === 'model' && (
                                    <button 
                                        onClick={() => speakText(msg.text)}
                                        className="absolute -right-6 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity p-1 text-slate-500 hover:text-emerald-400"
                                        title="Read aloud"
                                    >
                                        <Volume2 className="w-4 h-4" />
                                    </button>
                                )}
                            </div>
                        </div>
                    ))}
                    {isChatLoading && (
                        <div className="flex justify-start">
                            <div className="bg-slate-800 p-3 rounded-lg border border-slate-700 rounded-tl-none">
                                <Loader2 className="w-4 h-4 animate-spin text-emerald-500" />
                            </div>
                        </div>
                    )}
                </div>
            )}

            {/* Input (Disabled if Voice Active) */}
            <form onSubmit={handleSendMessage} className={`p-3 bg-slate-900 border-t border-slate-800 flex gap-2 transition-opacity ${isVoiceActive ? 'opacity-50 pointer-events-none' : 'opacity-100'}`}>
                <input 
                    className="flex-1 bg-slate-950 border border-slate-700 rounded p-2 text-sm text-white focus:border-emerald-500 outline-none placeholder-slate-600" 
                    placeholder={isVoiceActive ? "Voice Mode Active..." : (isAdmin ? "Ask Architect..." : "Message M...")}
                    value={chatInput}
                    onChange={e => setChatInput(e.target.value)}
                    disabled={isVoiceActive}
                />
                <button 
                    type="submit" 
                    disabled={isChatLoading || !chatInput.trim() || isVoiceActive}
                    className="bg-emerald-600 hover:bg-emerald-500 text-white p-2 rounded disabled:opacity-50 disabled:cursor-not-allowed"
                >
                    <Send className="w-4 h-4" />
                </button>
            </form>
        </div>

        {/* Right Col: Content Editor / Viewer */}
        <div className="w-1/2 bg-slate-900 rounded-xl border border-slate-800 flex flex-col overflow-hidden relative">
            {selectedItem ? (
              <>
                <div className="p-4 border-b border-slate-800 flex justify-between items-start bg-slate-950/50">
                    <div>
                         <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded uppercase font-bold tracking-widest mb-1 inline-block">
                             {activeType}
                         </span>
                         <h2 className="text-xl font-bold text-white leading-tight">{selectedItem.title}</h2>
                    </div>
                    {isAdmin && (
                        <button onClick={() => isEditing ? saveItem() : startEdit(selectedItem)} className={`p-2 rounded transition-colors ${isEditing ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'}`}>
                            {isEditing ? <CheckCircle className="w-5 h-5" /> : <Edit className="w-5 h-5" />}
                        </button>
                    )}
                </div>

                <div className="flex-1 p-4 overflow-y-auto custom-scrollbar">
                    {isEditing ? renderEditForm() : renderDetailContent()}
                </div>

                {/* Footer Action */}
                {!isEditing && !isAdmin && (
                    <div className="p-4 border-t border-slate-800 bg-slate-950/30">
                         {isCompleted(selectedItem.id) ? (
                             <button
                                onClick={() => onUploadPortfolio(String(selectedItem.id))}
                                className="w-full flex items-center justify-center space-x-2 bg-emerald-900/20 text-emerald-500 px-4 py-3 rounded border border-emerald-500/30 transition-all text-sm font-bold uppercase"
                             >
                                <CheckCircle className="w-5 h-5" />
                                <span>Update Portfolio</span>
                             </button>
                         ) : (
                            <button
                                onClick={() => onCompleteMission(String(selectedItem.id))}
                                className="w-full bg-slate-800 hover:bg-emerald-600 hover:text-white text-slate-300 px-4 py-3 rounded border border-slate-700 transition-all text-sm font-bold uppercase"
                            >
                                Mark Complete
                            </button>
                         )}
                    </div>
                )}
              </>
            ) : (
              <div className="flex items-center justify-center h-full text-slate-500 flex-col">
                <Lock className="w-12 h-12 mb-4 opacity-50" />
                <p>Select a file to access.</p>
              </div>
            )}
        </div>
      </div>
    </div>
  );
};
