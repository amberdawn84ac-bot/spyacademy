import React, { useEffect, useRef, useState } from 'react';
import { connectSecureLine } from '../services/geminiService';
import { Mic, MicOff, Activity, Radio } from 'lucide-react';

export const SecureLine: React.FC = () => {
  const [isActive, setIsActive] = useState(false);
  const [status, setStatus] = useState<'offline' | 'connecting' | 'online'>('offline');
  const [volume, setVolume] = useState(0); // For visualizing audio
  
  // Refs for audio processing
  const audioContextRef = useRef<AudioContext | null>(null);
  const inputSourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const closeConnectionRef = useRef<(() => void) | null>(null);
  
  // Helper to ensure AudioContext is ready
  const getAudioContext = () => {
    if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    }
    return audioContextRef.current;
  };

  const startSession = async () => {
    try {
      setStatus('connecting');
      const ctx = getAudioContext();
      if (ctx.state === 'suspended') await ctx.resume();

      // Get Microphone
      const stream = await navigator.mediaDevices.getUserMedia({ audio: {
          sampleRate: 16000,
          channelCount: 1,
          echoCancellation: true
      }});
      streamRef.current = stream;

      // Connect to Gemini
      const sessionPromise = connectSecureLine(
        (audioBuffer) => playAudioResponse(audioBuffer),
        () => handleDisconnect()
      );

      // Setup Input Processing (Mic -> Gemini)
      // We need a separate context for input to match 16kHz requirement usually, 
      // but let's downsample manually or let browser handle it. 
      // Simplified approach: Use main context and downsample if needed, 
      // but Live API expects 16khz PCM. 
      const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const source = inputCtx.createMediaStreamSource(stream);
      const processor = inputCtx.createScriptProcessor(4096, 1, 1);
      
      processor.onaudioprocess = (e) => {
        const inputData = e.inputBuffer.getChannelData(0);
        
        // Simple visualizer volume
        let sum = 0;
        for(let i = 0; i < inputData.length; i++) sum += inputData[i] * inputData[i];
        setVolume(Math.sqrt(sum / inputData.length));

        // Create 16-bit PCM Blob
        const l = inputData.length;
        const int16 = new Int16Array(l);
        for (let i = 0; i < l; i++) {
            int16[i] = inputData[i] * 32768;
        }
        
        // Convert to base64 manually to avoid library deps
        let binary = '';
        const bytes = new Uint8Array(int16.buffer);
        const len = bytes.byteLength;
        for (let i = 0; i < len; i++) {
            binary += String.fromCharCode(bytes[i]);
        }
        const b64 = btoa(binary);

        sessionPromise.then(session => {
            session.sendRealtimeInput({
                media: {
                    mimeType: 'audio/pcm;rate=16000',
                    data: b64
                }
            });
        });
      };

      source.connect(processor);
      processor.connect(inputCtx.destination);
      
      inputSourceRef.current = source;
      processorRef.current = processor;
      
      // Wait for session to actually resolve to enable UI
      const session = await sessionPromise;
      closeConnectionRef.current = () => session.close();
      
      setIsActive(true);
      setStatus('online');
      nextStartTimeRef.current = ctx.currentTime;

    } catch (err) {
      console.error("Connection failed", err);
      setStatus('offline');
      alert("Secure line encryption failed. Check microphone permissions.");
    }
  };

  const playAudioResponse = (arrayBuffer: ArrayBuffer) => {
      const ctx = getAudioContext();
      // PCM 16-bit to Float32
      const dataView = new DataView(arrayBuffer);
      const float32 = new Float32Array(arrayBuffer.byteLength / 2);
      for (let i = 0; i < float32.length; i++) {
        float32[i] = dataView.getInt16(i * 2, true) / 32768.0;
      }

      const audioBuffer = ctx.createBuffer(1, float32.length, 24000);
      audioBuffer.getChannelData(0).set(float32);

      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(ctx.destination);
      
      // Schedule
      const startTime = Math.max(ctx.currentTime, nextStartTimeRef.current);
      source.start(startTime);
      nextStartTimeRef.current = startTime + audioBuffer.duration;
  };

  const handleDisconnect = () => {
    if (closeConnectionRef.current) closeConnectionRef.current();
    if (streamRef.current) streamRef.current.getTracks().forEach(t => t.stop());
    if (processorRef.current) processorRef.current.disconnect();
    if (inputSourceRef.current) inputSourceRef.current.disconnect();
    
    setIsActive(false);
    setStatus('offline');
    setVolume(0);
  };

  return (
    <div className="h-full flex flex-col items-center justify-center relative overflow-hidden">
      {/* Background Pulse */}
      {isActive && (
         <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-96 h-96 bg-emerald-500/10 rounded-full animate-pulse blur-3xl"></div>
         </div>
      )}

      <div className="z-10 text-center space-y-8">
        <div className="relative inline-block">
          <div className={`w-32 h-32 rounded-full border-4 flex items-center justify-center transition-all duration-500 ${
            isActive 
                ? 'border-emerald-500 shadow-[0_0_50px_rgba(16,185,129,0.5)]' 
                : 'border-slate-700 bg-slate-900'
          }`}>
             {isActive ? (
                 <Activity className="w-12 h-12 text-emerald-400 animate-bounce" style={{ transform: `scale(${1 + volume * 5})` }} />
             ) : (
                 <Radio className="w-12 h-12 text-slate-600" />
             )}
          </div>
          {status === 'connecting' && (
              <div className="absolute inset-0 rounded-full border-t-4 border-emerald-500 animate-spin"></div>
          )}
        </div>

        <div>
            <h2 className="text-2xl font-bold text-white mb-2">SECURE VOICE UPLINK</h2>
            <p className="text-slate-400 font-mono text-sm">
                {status === 'offline' && "STATUS: DISCONNECTED"}
                {status === 'connecting' && "STATUS: HANDSHAKING..."}
                {status === 'online' && "STATUS: ENCRYPTED // LIVE"}
            </p>
        </div>

        <button
          onClick={isActive ? handleDisconnect : startSession}
          className={`px-8 py-4 rounded-full font-bold text-lg tracking-wider transition-all transform hover:scale-105 active:scale-95 flex items-center space-x-3 mx-auto ${
            isActive 
                ? 'bg-red-600 hover:bg-red-500 text-white shadow-lg shadow-red-900/50' 
                : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-900/50'
          }`}
        >
          {isActive ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          <span>{isActive ? 'TERMINATE UPLINK' : 'INITIATE CONTACT'}</span>
        </button>
      </div>
      
      <div className="absolute bottom-8 text-xs text-slate-600 font-mono">
        FREQUENCY: 24.558 GHz // CHANNEL: Q-BRANCH
      </div>
    </div>
  );
};