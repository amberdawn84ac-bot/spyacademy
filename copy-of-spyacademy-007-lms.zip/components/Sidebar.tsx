
import React from 'react';
import { ViewState, User } from '../types';
import { LayoutDashboard, Radio, Cpu, Globe, Briefcase, FileText, Users, LogOut, FlaskConical, Palette, Home, Sprout, Terminal, Mic } from 'lucide-react';

interface SidebarProps {
  currentView: ViewState;
  onNavigate: (view: ViewState) => void;
  user: User;
  onLogout: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentView, onNavigate, user, onLogout }) => {
  const navItems = [
    { view: ViewState.DASHBOARD, icon: LayoutDashboard, label: 'Graduation Tracker', roles: ['student', 'admin'] },
    { view: ViewState.MISSION_CONTROL, icon: Briefcase, label: 'Curriculum', roles: ['student', 'admin'] },
    { view: ViewState.SECURE_LINE, icon: Mic, label: 'Secure Line (Voice)', roles: ['student', 'admin'] },
    { view: ViewState.SCIENCE_LAB, icon: FlaskConical, label: 'Science Lab', roles: ['student', 'admin'] },
    { view: ViewState.FARM_PROJECTS, icon: Sprout, label: 'Farm Ops', roles: ['student', 'admin'] },
    { view: ViewState.ART_STUDIO, icon: Palette, label: 'Art Studio', roles: ['student', 'admin'] },
    { view: ViewState.CRYPTOGRAPHY, icon: Terminal, label: 'Cryptography (Spelling)', roles: ['student', 'admin'] },
    { view: ViewState.GADGET_LAB, icon: Cpu, label: 'Design (Gadgets)', roles: ['student', 'admin'] },
    { view: ViewState.PORTFOLIO, icon: FileText, label: 'My Portfolio', roles: ['student'] },
    { view: ViewState.RECRUIT_TRACKER, icon: Users, label: 'Student Roster', roles: ['admin'] },
  ];

  return (
    <div className="w-64 bg-slate-950 border-r border-slate-800 flex flex-col h-screen fixed left-0 top-0 z-10">
      <div className="p-6 border-b border-slate-800">
        <h1 className="text-2xl font-bold text-emerald-500 tracking-wider">MI6 LMS</h1>
        <p className="text-xs text-slate-500 mt-1 uppercase tracking-widest">Authorized Eyes Only</p>
      </div>
      <nav className="flex-1 p-4 space-y-2">
        {navItems.filter(item => item.roles.includes(user.role)).map((item) => (
          <button
            key={item.view}
            onClick={() => onNavigate(item.view)}
            className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 group ${
              currentView === item.view
                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                : 'text-slate-400 hover:bg-slate-900 hover:text-emerald-300'
            }`}
          >
            <item.icon className={`w-5 h-5 ${currentView === item.view ? 'text-emerald-400' : 'text-slate-500 group-hover:text-emerald-300'}`} />
            <span className="font-mono text-sm">{item.label}</span>
          </button>
        ))}
      </nav>
      <div className="p-4 border-t border-slate-800">
        <button 
            onClick={() => onNavigate(ViewState.LANDING)}
            className="w-full flex items-center justify-center space-x-2 bg-slate-900 hover:bg-slate-800 text-slate-500 hover:text-emerald-400 py-2 rounded text-xs transition-colors mb-4 border border-transparent hover:border-emerald-500/30"
        >
            <Home className="w-3 h-3" />
            <span>EXIT TO COVER (HOME)</span>
        </button>

        <div className="flex items-center space-x-3 mb-4">
          <div className="w-8 h-8 rounded-full bg-emerald-900/50 border border-emerald-500/30 flex items-center justify-center">
            <span className="text-xs font-bold text-emerald-400">{user.username.substring(0,2).toUpperCase()}</span>
          </div>
          <div className="flex-1 overflow-hidden">
             <div className="text-sm font-bold text-white truncate">{user.name}</div>
             <div className="text-xs text-slate-500 uppercase">{user.role}</div>
          </div>
        </div>
        <button 
            onClick={onLogout}
            className="w-full flex items-center justify-center space-x-2 bg-slate-900 hover:bg-red-900/20 text-slate-500 hover:text-red-400 py-2 rounded transition-colors"
        >
            <LogOut className="w-4 h-4" />
            <span>DISAVOW (LOGOUT)</span>
        </button>
      </div>
    </div>
  );
};
