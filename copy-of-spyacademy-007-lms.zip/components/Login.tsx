
import React, { useState } from 'react';
import { User, UserRole, Student } from '../types';
import { Fingerprint, Lock, ShieldAlert, UserPlus, ArrowRight, GraduationCap, Cloud } from 'lucide-react';

interface LoginProps {
  onLogin: (user: User) => void;
  onSignup: (name: string, username: string, grade: number, password?: string) => void;
  existingStudents: Student[];
  onSync: () => void;
}

export const Login: React.FC<LoginProps> = ({ onLogin, onSignup, existingStudents, onSync }) => {
  const [isLoginView, setIsLoginView] = useState(true);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState(''); 
  const [name, setName] = useState('');
  const [grade, setGrade] = useState(6);
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (isLoginView) {
        // --- LOGIN LOGIC ---
        if (username === 'admin' && password === 'admin') {
            onLogin({
                id: 'admin-01',
                username: 'admin',
                role: 'admin',
                name: 'M',
                avatar: 'M'
            });
            return;
        }

        const student = existingStudents.find(s => s.username === username);
        
        if (student) {
            // Check stored password if it exists, otherwise use defaults
            if (student.password) {
                if (student.password === password) {
                    onLogin(student);
                    return;
                }
            } else if (password === 'student' || password === 'secret') {
                // Legacy/Default password support
                onLogin(student);
                return;
            }
        }

        setError('Access Denied. Invalid Credentials.');
    } else {
        // --- SIGNUP LOGIC ---
        if (!name.trim() || !username.trim()) {
            setError("All fields required.");
            return;
        }
        if (existingStudents.find(s => s.username === username)) {
            setError("Codename already taken.");
            return;
        }
        
        onSignup(name, username, grade, password);
    }
  };

  return (
    <div className="min-h-screen bg-black flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-slate-950 border border-slate-800 rounded-2xl p-8 shadow-2xl relative overflow-hidden">
         {/* Decorative Grid */}
         <div className="absolute inset-0 bg-[linear-gradient(rgba(16,185,129,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(16,185,129,0.03)_1px,transparent_1px)] bg-[size:20px_20px] pointer-events-none"></div>

         <div className="relative z-10 text-center mb-8">
            <div className="w-16 h-16 bg-emerald-900/20 rounded-full flex items-center justify-center mx-auto mb-4 border border-emerald-500/30">
                <Fingerprint className="w-8 h-8 text-emerald-500" />
            </div>
            <h1 className="text-2xl font-bold text-white tracking-widest">SPY ACADEMY LMS</h1>
            <p className="text-xs text-slate-500 mt-2 font-mono">RESTRICTED ACCESS // LEVEL 5 CLEARANCE</p>
         </div>

         <div className="relative z-10 mb-6 flex bg-slate-900 p-1 rounded-lg">
             <button 
                type="button"
                onClick={() => { setIsLoginView(true); setError(''); }}
                className={`flex-1 py-2 text-xs font-bold rounded transition-all ${isLoginView ? 'bg-emerald-600 text-white' : 'text-slate-500 hover:text-white'}`}
             >
                 AGENT LOGIN
             </button>
             <button 
                type="button"
                onClick={() => { setIsLoginView(false); setError(''); }}
                className={`flex-1 py-2 text-xs font-bold rounded transition-all ${!isLoginView ? 'bg-emerald-600 text-white' : 'text-slate-500 hover:text-white'}`}
             >
                 NEW RECRUIT
             </button>
         </div>

         <form onSubmit={handleSubmit} className="relative z-10 space-y-6">
            {!isLoginView && (
                <div className="animate-in fade-in slide-in-from-left-4 duration-300 space-y-4">
                    <div>
                        <label className="block text-xs font-mono text-emerald-600 mb-2">FULL NAME</label>
                        <div className="relative">
                            <input 
                                type="text" 
                                value={name}
                                onChange={e => setName(e.target.value)}
                                className="w-full bg-slate-900 border border-slate-800 rounded text-white px-4 py-3 pl-10 focus:border-emerald-500 focus:outline-none focus:ring-1 focus:ring-emerald-500 transition-all font-mono"
                                placeholder="JAMES BOND"
                            />
                            <UserPlus className="w-4 h-4 text-slate-600 absolute left-3 top-1/2 -translate-y-1/2" />
                        </div>
                    </div>
                    <div>
                        <label className="block text-xs font-mono text-emerald-600 mb-2">GRADE LEVEL</label>
                        <div className="relative">
                             <select
                                value={grade}
                                onChange={e => setGrade(Number(e.target.value))}
                                className="w-full bg-slate-900 border border-slate-800 rounded text-white px-4 py-3 pl-10 focus:border-emerald-500 focus:outline-none focus:ring-1 focus:ring-emerald-500 transition-all font-mono appearance-none"
                             >
                                 <option value={6}>Grade 6</option>
                                 <option value={7}>Grade 7</option>
                                 <option value={8}>Grade 8</option>
                                 <option value={9}>Grade 9 (Freshman)</option>
                                 <option value={10}>Grade 10 (Sophomore)</option>
                                 <option value={11}>Grade 11 (Junior)</option>
                                 <option value={12}>Grade 12 (Senior)</option>
                             </select>
                            <GraduationCap className="w-4 h-4 text-slate-600 absolute left-3 top-1/2 -translate-y-1/2" />
                        </div>
                    </div>
                </div>
            )}

            <div>
                <label className="block text-xs font-mono text-emerald-600 mb-2">AGENT CODENAME</label>
                <div className="relative">
                    <input 
                        type="text" 
                        value={username}
                        onChange={e => setUsername(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 rounded text-white px-4 py-3 pl-10 focus:border-emerald-500 focus:outline-none focus:ring-1 focus:ring-emerald-500 transition-all font-mono"
                        placeholder={isLoginView ? "ENTER CODENAME" : "CREATE CODENAME"}
                    />
                    <ShieldAlert className="w-4 h-4 text-slate-600 absolute left-3 top-1/2 -translate-y-1/2" />
                </div>
            </div>
            
             <div className="animate-in fade-in slide-in-from-right-4 duration-300">
                <label className="block text-xs font-mono text-emerald-600 mb-2">PASSPHRASE</label>
                <div className="relative">
                    <input 
                        type="password" 
                        value={password}
                        onChange={e => setPassword(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 rounded text-white px-4 py-3 pl-10 focus:border-emerald-500 focus:outline-none focus:ring-1 focus:ring-emerald-500 transition-all font-mono"
                        placeholder={isLoginView ? "••••••••" : "CREATE PASSWORD"}
                    />
                    <Lock className="w-4 h-4 text-slate-600 absolute left-3 top-1/2 -translate-y-1/2" />
                </div>
                {isLoginView && <div className="mt-2 text-[10px] text-slate-500">Hint: admin/admin or jb007/student</div>}
            </div>

            {error && (
                <div className="bg-red-500/10 border border-red-500/50 text-red-400 px-4 py-2 rounded text-xs font-mono text-center">
                    {error}
                </div>
            )}

            <button 
                type="submit"
                className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3 rounded shadow-lg shadow-emerald-900/20 transition-all transform active:scale-[0.98] flex items-center justify-center space-x-2"
            >
                <span>{isLoginView ? 'AUTHENTICATE' : 'INITIALIZE PROFILE'}</span>
                <ArrowRight className="w-4 h-4" />
            </button>
            
            <div className="pt-4 border-t border-slate-800">
                <button 
                    type="button" 
                    onClick={onSync}
                    className="w-full flex items-center justify-center space-x-2 text-slate-500 hover:text-emerald-500 text-xs font-mono transition-colors"
                >
                    <Cloud className="w-3 h-3" />
                    <span>SECURE CLOUD UPLINK (RESTORE DATA)</span>
                </button>
            </div>
         </form>
      </div>
    </div>
  );
};
