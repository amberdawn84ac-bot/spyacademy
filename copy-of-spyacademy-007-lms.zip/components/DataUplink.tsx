
import React, { useState } from 'react';
import { Download, Upload, X, Shield, FileJson, Copy, Check } from 'lucide-react';
import { Student } from '../types';

interface DataUplinkProps {
  data: Student[];
  onImport: (data: Student[]) => void;
  onClose: () => void;
}

export const DataUplink: React.FC<DataUplinkProps> = ({ data, onImport, onClose }) => {
  const [mode, setMode] = useState<'export' | 'import'>('export');
  const [importText, setImportText] = useState('');
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState('');

  const handleCopy = () => {
    navigator.clipboard.writeText(JSON.stringify(data, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `spy-academy-backup-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleImport = () => {
    try {
      setError('');
      if (!importText.trim()) return;
      
      const parsed = JSON.parse(importText);
      if (!Array.isArray(parsed)) {
          throw new Error("Invalid format: Root must be an array of agents.");
      }
      
      // Basic validation check for student structure
      if (parsed.length > 0 && (!parsed[0].id || !parsed[0].progress)) {
          throw new Error("Invalid data: Missing required agent fields.");
      }

      onImport(parsed);
      onClose();
    } catch (e) {
      setError("Decryption Failed: Invalid Data Format.");
    }
  };

  return (
    <div className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
      <div className="w-full max-w-2xl bg-slate-900 border border-slate-700 rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-6 border-b border-slate-800 bg-slate-950 flex justify-between items-center">
            <div className="flex items-center space-x-3">
                <Shield className="w-6 h-6 text-emerald-500" />
                <div>
                    <h2 className="text-xl font-bold text-white tracking-widest">SECURE CLOUD UPLINK</h2>
                    <p className="text-xs text-slate-500 font-mono">ENCRYPTED CHANNEL // MANUAL SYNC PROTOCOL</p>
                </div>
            </div>
            <button onClick={onClose} className="text-slate-500 hover:text-white transition-colors">
                <X className="w-6 h-6" />
            </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-slate-800">
            <button 
                onClick={() => setMode('export')}
                className={`flex-1 py-4 text-sm font-bold tracking-wider transition-colors ${mode === 'export' ? 'bg-emerald-900/20 text-emerald-500 border-b-2 border-emerald-500' : 'text-slate-500 hover:text-slate-300'}`}
            >
                EXTRACT DATA (SAVE)
            </button>
            <button 
                onClick={() => setMode('import')}
                className={`flex-1 py-4 text-sm font-bold tracking-wider transition-colors ${mode === 'import' ? 'bg-blue-900/20 text-blue-500 border-b-2 border-blue-500' : 'text-slate-500 hover:text-slate-300'}`}
            >
                INGEST DATA (LOAD)
            </button>
        </div>

        {/* Content */}
        <div className="flex-1 p-8 overflow-y-auto">
            {mode === 'export' ? (
                <div className="space-y-6 animate-in fade-in slide-in-from-left-4 duration-300">
                    <div className="bg-emerald-900/10 border border-emerald-500/30 p-4 rounded-lg">
                        <h3 className="text-emerald-400 font-bold mb-2 flex items-center gap-2">
                            <Download className="w-4 h-4" />
                            Ready for Extraction
                        </h3>
                        <p className="text-sm text-slate-400">
                            Download your mission file to safe storage (Google Drive, iCloud, etc). 
                            You can upload this file on another device to restore your progress.
                        </p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <button 
                            onClick={handleDownload}
                            className="flex flex-col items-center justify-center p-6 bg-slate-800 hover:bg-slate-700 border border-slate-600 rounded-xl transition-all group"
                        >
                            <FileJson className="w-10 h-10 text-emerald-500 mb-3 group-hover:scale-110 transition-transform" />
                            <span className="font-bold text-white">Download Mission File</span>
                            <span className="text-xs text-slate-500 mt-1">.json format</span>
                        </button>
                        
                        <button 
                            onClick={handleCopy}
                            className="flex flex-col items-center justify-center p-6 bg-slate-800 hover:bg-slate-700 border border-slate-600 rounded-xl transition-all group"
                        >
                            {copied ? <Check className="w-10 h-10 text-emerald-500 mb-3" /> : <Copy className="w-10 h-10 text-emerald-500 mb-3 group-hover:scale-110 transition-transform" />}
                            <span className="font-bold text-white">{copied ? 'Copied to Clipboard' : 'Copy Data String'}</span>
                            <span className="text-xs text-slate-500 mt-1">For manual paste</span>
                        </button>
                    </div>
                </div>
            ) : (
                <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                     <div className="bg-blue-900/10 border border-blue-500/30 p-4 rounded-lg">
                        <h3 className="text-blue-400 font-bold mb-2 flex items-center gap-2">
                            <Upload className="w-4 h-4" />
                            Ingest Protocol
                        </h3>
                        <p className="text-sm text-slate-400">
                            Paste your mission data string below to restore your progress. 
                            <span className="text-red-400 font-bold ml-1">WARNING: This will overwrite current local data.</span>
                        </p>
                    </div>

                    <textarea
                        value={importText}
                        onChange={(e) => setImportText(e.target.value)}
                        placeholder="Paste mission data JSON here..."
                        className="w-full h-48 bg-black border border-slate-700 rounded-lg p-4 text-xs font-mono text-emerald-500 focus:outline-none focus:border-blue-500 transition-colors"
                    />

                    {error && (
                        <div className="text-red-400 text-xs font-mono bg-red-900/10 p-2 rounded border border-red-500/30">
                            Error: {error}
                        </div>
                    )}

                    <button 
                        onClick={handleImport}
                        disabled={!importText}
                        className="w-full py-4 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg shadow-lg shadow-blue-900/20 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        INITIATE DATA RESTORE
                    </button>
                </div>
            )}
        </div>
      </div>
    </div>
  );
};
