import React, { useState } from 'react';
import { gatherIntel } from '../services/geminiService';
import { Search, Globe, ArrowRight, ExternalLink } from 'lucide-react';

export const IntelCenter: React.FC = () => {
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{text: string, sources: any[]} | null>(null);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    setLoading(true);
    try {
      const data = await gatherIntel(`Provide a detailed tactical dossier on: ${query}`);
      setResult({
          text: data.text,
          sources: data.groundingChunks || []
      });
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto h-full flex flex-col">
      <div className="mb-8 text-center">
        <h2 className="text-3xl font-bold text-white mb-2 tracking-tight">Global Intel Database</h2>
        <p className="text-slate-400">Access real-time information for mission planning via Secure Uplink.</p>
      </div>

      <form onSubmit={handleSearch} className="mb-8 relative">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Enter target name, location, or organization..."
          className="w-full bg-slate-900 border border-slate-700 rounded-full py-4 px-6 pl-12 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all shadow-lg shadow-black/50"
        />
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 w-5 h-5" />
        <button
          type="submit"
          disabled={loading}
          className="absolute right-2 top-1/2 -translate-y-1/2 bg-emerald-600 hover:bg-emerald-500 text-white p-2 rounded-full transition-colors disabled:opacity-50"
        >
          {loading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <ArrowRight className="w-5 h-5" />}
        </button>
      </form>

      {result && (
        <div className="flex-1 bg-slate-900 rounded-xl border border-slate-800 p-8 overflow-y-auto animate-in fade-in slide-in-from-bottom-4 duration-500">
          <div className="flex items-center space-x-2 mb-6">
            <Globe className="w-5 h-5 text-emerald-500" />
            <span className="font-mono text-emerald-500 text-sm">INTEL_VERIFIED_</span>
          </div>
          
          <div className="prose prose-invert prose-emerald max-w-none mb-8">
             <div className="whitespace-pre-wrap leading-relaxed text-slate-300">
                {result.text}
             </div>
          </div>

          {result.sources.length > 0 && (
            <div className="border-t border-slate-800 pt-6">
              <h4 className="text-xs font-mono text-slate-500 uppercase tracking-wider mb-4">Intercepted Sources</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {result.sources.map((chunk, idx) => {
                    const web = chunk.web;
                    if (!web) return null;
                    return (
                        <a 
                            key={idx} 
                            href={web.uri} 
                            target="_blank" 
                            rel="noreferrer"
                            className="flex items-center justify-between p-3 bg-slate-950 rounded border border-slate-800 hover:border-emerald-500/50 transition-colors group"
                        >
                            <span className="text-sm text-slate-400 truncate pr-4 group-hover:text-emerald-400">{web.title}</span>
                            <ExternalLink className="w-3 h-3 text-slate-600 group-hover:text-emerald-500 flex-shrink-0" />
                        </a>
                    )
                })}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};