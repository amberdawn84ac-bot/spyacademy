
import React, { useState } from 'react';
import { FlaskConical, Key, ArrowLeft, Clock, AlertTriangle, Edit, CheckCircle, Plus } from 'lucide-react';
import { ViewState, User } from '../types';

interface ScienceLabProps {
  onNavigate: (view: ViewState) => void;
  experiments: Experiment[];
  user: User | null;
  onUpdate: (experiments: Experiment[]) => void;
  onComplete?: (id: number) => void;
  completedIds?: (string | number)[];
  variant?: 'public' | 'private';
}

interface Experiment {
  id: number;
  title: string;
  image: string;
  wowFactor: string;
  concepts: string[];
  connection: string;
  materials: string[];
  instructions: { title?: string, steps: string[] }[];
  safety: string[];
}

export const ScienceLab: React.FC<ScienceLabProps> = ({ onNavigate, experiments, user, onUpdate, onComplete, completedIds = [], variant = 'public' }) => {
  const [selectedExp, setSelectedExp] = useState<Experiment | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState<Partial<Experiment>>({});

  const isAdmin = user?.role === 'admin';
  const isStudent = user?.role === 'student';
  const isPrivate = variant === 'private';

  const startEdit = (exp: Experiment) => {
      setEditForm(JSON.parse(JSON.stringify(exp))); 
      setIsEditing(true);
      setSelectedExp(exp);
  };

  const startCreate = () => {
      setEditForm({
          id: experiments.length + 1,
          title: "New Experiment",
          image: "https://images.unsplash.com/photo-1532094349884-543bc11b234d?q=80&w=2070&auto=format&fit=crop",
          wowFactor: "Short description.",
          concepts: ["Chemistry"],
          connection: "Scientific principle connection.",
          materials: ["Material 1"],
          instructions: [{title: "Procedure", steps: ["Step 1"]}],
          safety: ["Safety first."]
      });
      setIsEditing(true);
      setSelectedExp(null);
  };

  const saveExperiment = () => {
      if (!editForm.title) return;
      
      let newExps = [...experiments];
      const index = newExps.findIndex(e => e.id === editForm.id);
      
      if (index >= 0) {
          newExps[index] = editForm as Experiment;
      } else {
          newExps.push(editForm as Experiment);
      }
      
      onUpdate(newExps);
      setIsEditing(false);
      if (index >= 0) setSelectedExp(editForm as Experiment);
      else setSelectedExp(null);
  };

  // Navbar component reused for consistency
  const Nav = () => (
    <nav className="w-full py-6 px-4 md:px-8 flex flex-col md:flex-row justify-between items-center border-b border-[#e6e2d8] bg-[#f7f5f0]/95 backdrop-blur-sm sticky top-0 z-50">
        <div className="text-2xl tracking-[0.2em] font-bold text-[#2c241b] mb-4 md:mb-0 cursor-pointer" onClick={() => onNavigate(ViewState.LANDING)}>DEAR ADELINE CO.</div>
        <div className="flex flex-col md:flex-row items-center space-y-4 md:space-y-0 md:space-x-8 text-xs md:text-sm tracking-widest font-sans text-[#6b5d4d]">
          <button onClick={() => onNavigate(ViewState.FARM_PROJECTS)} className="hover:text-[#8c7b64] transition-colors uppercase">FARM PROJECTS</button>
          <button onClick={() => onNavigate(ViewState.ART_STUDIO)} className="hover:text-[#8c7b64] transition-colors uppercase">ART PROJECTS</button>
          <button onClick={() => onNavigate(ViewState.SCIENCE_LAB)} className="text-[#8c7b64] border-b border-[#8c7b64] pb-1 uppercase">SCIENCE EXPERIMENTS</button>
          <button
            onClick={() => onNavigate(ViewState.LOGIN)}
            className="flex items-center space-x-2 bg-[#2c241b] text-[#f7f5f0] px-6 py-2 rounded-sm hover:bg-[#4a4036] transition-all"
          >
            <Key className="w-3 h-3" />
            <span>SPY ACADEMY</span>
          </button>
        </div>
    </nav>
  );

  // Edit Form Overlay
  const Editor = () => (
      <div className="fixed inset-0 z-[60] bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto rounded shadow-2xl font-sans">
              <h2 className="text-2xl font-serif text-[#2c241b] mb-6">Edit Experiment</h2>
              <div className="space-y-4 text-gray-800">
                  <input className="w-full border p-2 text-sm" placeholder="Title" value={editForm.title} onChange={e => setEditForm({...editForm, title: e.target.value})} />
                  <input className="w-full border p-2 text-sm" placeholder="Image URL" value={editForm.image} onChange={e => setEditForm({...editForm, image: e.target.value})} />
                  <textarea className="w-full border p-2 text-sm" placeholder="Observation/Wow Factor" value={editForm.wowFactor} onChange={e => setEditForm({...editForm, wowFactor: e.target.value})} />
                  <textarea className="w-full border p-2 text-sm" placeholder="Connection" value={editForm.connection} onChange={e => setEditForm({...editForm, connection: e.target.value})} />
                  
                  <div>
                      <label className="block text-xs uppercase text-gray-500 mb-1">Materials (comma separated)</label>
                      <textarea className="w-full border p-2 text-sm" value={editForm.materials?.join(', ')} onChange={e => setEditForm({...editForm, materials: e.target.value.split(', ')})} />
                  </div>
                   <div>
                       <label className="block text-xs uppercase text-gray-500 mb-1">Concepts (comma separated)</label>
                       <input className="w-full border p-2 text-sm" value={editForm.concepts?.join(', ')} onChange={e => setEditForm({...editForm, concepts: e.target.value.split(', ')})} />
                  </div>
                   <div>
                       <label className="block text-xs uppercase text-gray-500 mb-1">Safety (comma separated)</label>
                       <textarea className="w-full border p-2 text-sm" value={editForm.safety?.join(', ')} onChange={e => setEditForm({...editForm, safety: e.target.value.split(', ')})} />
                  </div>
                  
                  <div className="flex justify-end gap-2 pt-4 border-t">
                      <button onClick={() => setIsEditing(false)} className="px-4 py-2 text-gray-500 hover:text-black">Cancel</button>
                      <button onClick={saveExperiment} className="px-4 py-2 bg-[#2c241b] text-white hover:bg-[#4a4036]">Save Changes</button>
                  </div>
              </div>
          </div>
      </div>
  );

  if (selectedExp) {
      const isCompleted = completedIds.includes(selectedExp.id);

      return (
          <div className={isPrivate ? "min-h-full bg-slate-900 text-slate-200" : "min-h-screen bg-[#f7f5f0] text-[#4a4036] font-serif"}>
              {isEditing && <Editor />}
              {!isPrivate && <Nav />}
              <div className={isPrivate ? "p-6 overflow-y-auto h-full" : "max-w-4xl mx-auto py-12 px-8"}>
                  <div className="flex justify-between items-center mb-8">
                    <button onClick={() => setSelectedExp(null)} className={isPrivate ? "flex items-center space-x-2 text-emerald-500 hover:text-white transition-colors" : "flex items-center space-x-2 text-[#8c7b64] text-xs font-sans tracking-widest hover:text-[#5e5040] transition-colors"}>
                        <ArrowLeft className="w-4 h-4" />
                        <span>BACK TO LIST</span>
                    </button>
                     <div className="flex space-x-3">
                        {isStudent && onComplete && (
                            <button 
                                onClick={() => !isCompleted && onComplete(selectedExp.id)}
                                className={`flex items-center space-x-2 px-4 py-2 text-xs font-sans tracking-widest transition-all ${
                                    isCompleted 
                                    ? 'bg-emerald-900/30 text-emerald-500 hover:bg-emerald-900/50' 
                                    : (isPrivate ? 'bg-emerald-600 text-white hover:bg-emerald-500' : 'bg-[#2c241b] text-white hover:bg-[#4a4036]')
                                }`}
                            >
                                <CheckCircle className="w-3 h-3" />
                                <span>{isCompleted ? 'EDIT PORTFOLIO' : 'MARK COMPLETE'}</span>
                            </button>
                        )}
                        {isAdmin && (
                            <button onClick={() => startEdit(selectedExp)} className="flex items-center space-x-2 bg-slate-800 text-white px-4 py-2 text-xs font-sans tracking-widest hover:bg-slate-700">
                                <Edit className="w-3 h-3" />
                                <span>EDIT</span>
                            </button>
                        )}
                    </div>
                  </div>
                  
                  <div className="mb-10 text-center">
                      <div className="flex justify-center gap-2 mb-4">
                        {selectedExp.concepts.map((c, i) => (
                            <span key={i} className={`text-[10px] uppercase tracking-[0.2em] px-3 py-1 ${isPrivate ? "border border-emerald-500/30 text-emerald-400" : "font-sans border border-[#d4c5b0] text-[#6b5d4d]"}`}>{c}</span>
                        ))}
                      </div>
                      <h1 className={isPrivate ? "text-4xl font-bold text-white mb-6" : "text-4xl md:text-6xl text-[#2c241b] mb-6 leading-tight"}>{selectedExp.title}</h1>
                      <div className={isPrivate ? "w-16 h-1 bg-emerald-500 mx-auto" : "w-16 h-1 bg-[#d4c5b0] mx-auto"}></div>
                  </div>

                  <img src={selectedExp.image} alt={selectedExp.title} className="w-full aspect-video object-cover mb-12 shadow-sm rounded-lg" />

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
                      <div className="md:col-span-2">
                          <h2 className={isPrivate ? "text-2xl font-bold text-white mb-6" : "text-2xl italic mb-6 text-[#2c241b]"}>The Observation</h2>
                          <p className={isPrivate ? "text-lg leading-relaxed text-slate-300 mb-8" : "text-lg leading-relaxed text-[#6b5d4d] mb-8 font-light"}>
                              {selectedExp.wowFactor}
                          </p>
                          
                          <div className="mb-10">
                              <h3 className={isPrivate ? "text-xs tracking-widest uppercase text-emerald-500 border-b border-slate-800 pb-2 mb-6" : "font-sans text-xs tracking-widest uppercase text-[#2c241b] border-b border-[#e6e2d8] pb-2 mb-6"}>Procedure</h3>
                              {selectedExp.instructions.map((section, idx) => (
                                  <div key={idx} className="mb-6">
                                      <h4 className={isPrivate ? "font-bold text-white mb-2" : "font-bold mb-2"}>{section.title}</h4>
                                      <ol className="list-decimal list-inside space-y-2 text-inherit opacity-80">
                                          {section.steps.map((step, sIdx) => (
                                              <li key={sIdx}>{step}</li>
                                          ))}
                                      </ol>
                                  </div>
                              ))}
                          </div>

                          <div className={isPrivate ? "bg-slate-950 p-8 border border-slate-800 rounded" : "bg-[#efede6] p-8 border border-[#e6e2d8]"}>
                              <div className={isPrivate ? "flex items-center space-x-3 mb-4 text-emerald-500" : "flex items-center space-x-3 mb-4 text-[#8c7b64]"}>
                                  <FlaskConical className="w-6 h-6" />
                                  <h3 className="text-xs tracking-widest uppercase font-bold">The Connection</h3>
                              </div>
                              <p className="italic opacity-80">"{selectedExp.connection}"</p>
                          </div>
                      </div>

                      <div className="md:col-span-1 space-y-8">
                          <div>
                              <h3 className={isPrivate ? "text-xs tracking-widest uppercase text-emerald-500 border-b border-slate-800 pb-2 mb-4" : "font-sans text-xs tracking-widest uppercase text-[#2c241b] border-b border-[#e6e2d8] pb-2 mb-4"}>Materials Needed</h3>
                              <ul className="space-y-2 text-sm opacity-80">
                                  {selectedExp.materials.map((m, i) => (
                                      <li key={i} className="flex items-start space-x-2">
                                          <span className="opacity-50">•</span>
                                          <span>{m}</span>
                                      </li>
                                  ))}
                              </ul>
                          </div>

                          <div className={isPrivate ? "bg-red-900/20 border border-red-500/30 p-6 rounded" : "bg-red-50 border border-red-100 p-6"}>
                              <div className="flex items-center space-x-2 text-red-400 mb-3">
                                  <AlertTriangle className="w-4 h-4" />
                                  <span className="text-[10px] tracking-widest uppercase font-bold">Safety First</span>
                              </div>
                              <ul className="space-y-1 text-xs text-red-400/80">
                                  {selectedExp.safety.map((s, i) => (
                                      <li key={i}>{s}</li>
                                  ))}
                              </ul>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      );
  }

  return (
    <div className={isPrivate ? "min-h-full bg-slate-900 text-slate-200" : "min-h-screen bg-[#f7f5f0] text-[#4a4036] font-serif selection:bg-[#d4c5b0] selection:text-[#2c241b]"}>
      {isEditing && <Editor />}
      {!isPrivate && <Nav />}
      
      {!isPrivate && (
        <header className="py-24 px-8 text-center bg-[#efede6] border-b border-[#e6e2d8]">
            <div className="max-w-4xl mx-auto">
                <div className="flex items-center justify-center space-x-2 text-[#8c7b64] mb-4">
                    <FlaskConical className="w-5 h-5" />
                    <span className="text-xs font-sans tracking-[0.2em] uppercase">Curriculum Category</span>
                </div>
                <h1 className="text-5xl md:text-7xl mb-6 text-[#2c241b]">Science Experiments</h1>
                <p className="text-lg text-[#6b5d4d] max-w-2xl mx-auto leading-relaxed">
                    Backyard chemistry, physics in motion, and the wonder of creation.
                </p>
                {isAdmin && (
                    <button onClick={startCreate} className="mt-8 bg-[#2c241b] text-white px-6 py-3 text-xs font-sans tracking-widest hover:bg-[#4a4036] shadow-lg">
                        ADD NEW EXPERIMENT
                    </button>
                )}
            </div>
        </header>
      )}

      {isPrivate && (
          <div className="flex items-center justify-between mb-6 border-b border-slate-800 pb-4">
              <h2 className="text-2xl font-bold text-white">Science Lab</h2>
              {isAdmin && (
                 <button onClick={startCreate} className="bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2 rounded text-xs font-bold">
                     ADD EXPERIMENT
                 </button>
             )}
          </div>
      )}

      <main className={isPrivate ? "grid grid-cols-1 md:grid-cols-3 gap-6" : "max-w-7xl mx-auto py-16 px-8 grid grid-cols-1 md:grid-cols-2 gap-12"}>
          {experiments.map((exp) => (
              <article key={exp.id} onClick={() => setSelectedExp(exp)} className={`group cursor-pointer ${isPrivate ? "bg-slate-950 border border-slate-800 rounded-lg overflow-hidden hover:border-emerald-500/50 transition-colors" : ""}`}>
                  <div className={`aspect-[3/2] relative overflow-hidden ${isPrivate ? "border-b border-slate-800" : "bg-[#e6e2d8] mb-6"}`}>
                      <img src={exp.image} alt={exp.title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
                      <div className={isPrivate ? "absolute bottom-0 left-0 bg-slate-900/90 px-3 py-1 text-[10px] font-mono text-emerald-400 border-t border-r border-slate-700" : "absolute bottom-0 left-0 bg-[#f7f5f0] px-4 py-2 text-[10px] tracking-[0.2em] font-sans uppercase border-t border-r border-[#d4c5b0]"}>
                            {exp.concepts[0]}
                      </div>
                      {completedIds.includes(exp.id) && (
                          <div className="absolute top-2 right-2 bg-emerald-500 text-white px-2 py-0.5 text-[10px] font-bold rounded">
                              DONE
                          </div>
                      )}
                  </div>
                  <div className={isPrivate ? "p-4" : ""}>
                    <h3 className={isPrivate ? "text-lg font-bold text-white mb-2" : "text-3xl mb-3 text-[#2c241b] group-hover:text-[#8c7b64] transition-colors"}>{exp.title}</h3>
                    <p className={isPrivate ? "text-xs text-slate-400 line-clamp-2 mb-3" : "text-[#6b5d4d] font-sans text-sm leading-relaxed mb-4 line-clamp-2"}>
                        {exp.wowFactor}
                    </p>
                    <span className={isPrivate ? "text-xs text-emerald-500 font-mono" : "text-xs font-sans tracking-widest text-[#2c241b] border-b border-[#2c241b] pb-0.5 group-hover:text-[#8c7b64] group-hover:border-[#8c7b64] transition-all"}>
                        {isPrivate ? "ACCESS FILE >" : "VIEW EXPERIMENT"}
                    </span>
                  </div>
              </article>
          ))}
      </main>
    </div>
  );
};
