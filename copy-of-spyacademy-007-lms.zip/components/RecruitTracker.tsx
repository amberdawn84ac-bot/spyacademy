
import React from 'react';
import { Student } from '../types';
import { Users, BookOpen, Trophy, Database } from 'lucide-react';
import { CURRICULUM } from '../data';

interface RecruitTrackerProps {
  students: Student[];
  onSync: () => void;
}

export const RecruitTracker: React.FC<RecruitTrackerProps> = ({ students, onSync }) => {
  const totalMissions = CURRICULUM.length;

  return (
    <div className="h-full flex flex-col">
      <div className="mb-8 flex justify-between items-start">
        <div>
            <h2 className="text-3xl font-bold text-white mb-2 tracking-tight">Recruit Progress Tracker</h2>
            <p className="text-slate-400">Monitor agent status and graduation eligibility.</p>
        </div>
        <button 
            onClick={onSync}
            className="flex items-center space-x-2 bg-slate-800 hover:bg-emerald-900/50 border border-slate-700 hover:border-emerald-500/50 text-slate-300 hover:text-emerald-400 px-4 py-2 rounded-lg transition-all"
        >
            <Database className="w-4 h-4" />
            <span className="text-xs font-bold">BACKUP DATABASE</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 flex items-center space-x-4">
              <div className="p-3 bg-emerald-500/10 rounded-full text-emerald-500">
                  <Users className="w-8 h-8" />
              </div>
              <div>
                  <div className="text-2xl font-bold text-white">{students.length}</div>
                  <div className="text-xs text-slate-500 uppercase tracking-wide">Active Agents</div>
              </div>
          </div>
          <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 flex items-center space-x-4">
              <div className="p-3 bg-blue-500/10 rounded-full text-blue-500">
                  <BookOpen className="w-8 h-8" />
              </div>
              <div>
                  <div className="text-2xl font-bold text-white">{totalMissions}</div>
                  <div className="text-xs text-slate-500 uppercase tracking-wide">Total Units</div>
              </div>
          </div>
      </div>

      <div className="bg-slate-950 rounded-xl border border-slate-800 overflow-hidden flex-1">
          <div className="overflow-x-auto">
              <table className="w-full text-left">
                  <thead>
                      <tr className="bg-slate-900 border-b border-slate-800">
                          <th className="p-4 text-xs font-mono text-slate-500 uppercase">Agent Name</th>
                          <th className="p-4 text-xs font-mono text-slate-500 uppercase">Codename</th>
                          <th className="p-4 text-xs font-mono text-slate-500 uppercase">Grade</th>
                          <th className="p-4 text-xs font-mono text-slate-500 uppercase">Status</th>
                          <th className="p-4 text-xs font-mono text-slate-500 uppercase">Progress</th>
                          <th className="p-4 text-xs font-mono text-slate-500 uppercase">Current Unit</th>
                      </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                      {students.map((student) => {
                          const completed = student.progress.completedMissionIds.length;
                          const percent = Math.round((completed / totalMissions) * 100);
                          const currentUnit = CURRICULUM.find(m => !student.progress.completedMissionIds.includes(m.id));

                          return (
                              <tr key={student.id} className="hover:bg-slate-900/50 transition-colors">
                                  <td className="p-4">
                                      <div className="font-medium text-white">{student.name}</div>
                                  </td>
                                  <td className="p-4">
                                      <div className="text-sm font-mono text-emerald-500">{student.username}</div>
                                  </td>
                                  <td className="p-4">
                                      <span className="text-xs bg-slate-800 px-2 py-1 rounded text-slate-400 border border-slate-700">
                                          GR {student.grade || 12}
                                      </span>
                                  </td>
                                  <td className="p-4">
                                      <span className={`text-[10px] px-2 py-0.5 rounded uppercase ${percent === 100 ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-400'}`}>
                                          {percent === 100 ? 'GRADUATED' : 'ACTIVE'}
                                      </span>
                                  </td>
                                  <td className="p-4 w-64">
                                      <div className="flex items-center space-x-3">
                                          <div className="flex-1 h-2 bg-slate-800 rounded-full overflow-hidden">
                                              <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${percent}%` }}></div>
                                          </div>
                                          <span className="text-xs font-mono text-slate-400">{percent}%</span>
                                      </div>
                                  </td>
                                  <td className="p-4">
                                      <div className="text-sm text-slate-300 truncate max-w-xs">
                                          {currentUnit ? currentUnit.title : "All Units Completed"}
                                      </div>
                                  </td>
                              </tr>
                          );
                      })}
                  </tbody>
              </table>
          </div>
      </div>
    </div>
  );
};
