import React from 'react';
import { ViewState } from '../types';
import { Sprout, Palette, FlaskConical, Key } from 'lucide-react';

interface LandingPageProps {
  onNavigate: (view: ViewState) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onNavigate }) => {
  return (
    <div className="min-h-screen bg-[#f7f5f0] text-[#4a4036] font-serif selection:bg-[#d4c5b0] selection:text-[#2c241b]">
      {/* Navigation */}
      <nav className="w-full py-6 px-4 md:px-8 flex flex-col md:flex-row justify-between items-center border-b border-[#e6e2d8] sticky top-0 bg-[#f7f5f0]/95 backdrop-blur-sm z-50 transition-all">
        <div className="text-2xl tracking-[0.2em] font-bold text-[#2c241b] mb-4 md:mb-0">DEAR ADELINE CO.</div>
        <div className="flex flex-col md:flex-row items-center space-y-4 md:space-y-0 md:space-x-8 text-xs md:text-sm tracking-widest font-sans text-[#6b5d4d]">
          <button onClick={() => onNavigate(ViewState.FARM_PROJECTS)} className="hover:text-[#8c7b64] transition-colors border-b border-transparent hover:border-[#8c7b64] pb-1 uppercase">FARM PROJECTS</button>
          <button onClick={() => onNavigate(ViewState.ART_STUDIO)} className="hover:text-[#8c7b64] transition-colors border-b border-transparent hover:border-[#8c7b64] pb-1 uppercase">ART PROJECTS</button>
          <button onClick={() => onNavigate(ViewState.SCIENCE_LAB)} className="hover:text-[#8c7b64] transition-colors border-b border-transparent hover:border-[#8c7b64] pb-1 uppercase">SCIENCE EXPERIMENTS</button>
          <button
            onClick={() => onNavigate(ViewState.LOGIN)}
            className="flex items-center space-x-2 bg-[#2c241b] text-[#f7f5f0] px-6 py-2 rounded-sm hover:bg-[#4a4036] transition-all transform hover:-translate-y-0.5 shadow-md hover:shadow-lg"
          >
            <Key className="w-3 h-3" />
            <span>SPY ACADEMY</span>
          </button>
        </div>
      </nav>

      {/* Hero */}
      <header className="relative py-32 px-8 text-center bg-[#efede6] border-b border-[#e6e2d8] overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full opacity-5 bg-[url('https://www.transparenttextures.com/patterns/paper.png')]"></div>
        <div className="max-w-4xl mx-auto relative z-10">
            <h1 className="text-5xl md:text-8xl mb-6 text-[#2c241b] leading-tight font-medium">
                Cultivating Wonder <br/> 
                <span className="italic text-[#6b5d4d] text-4xl md:text-6xl font-light">in the everyday</span>
            </h1>
            <div className="w-24 h-1 bg-[#d4c5b0] mx-auto mb-8"></div>
            <p className="text-lg md:text-xl text-[#6b5d4d] font-sans max-w-2xl mx-auto leading-relaxed tracking-wide">
                A collection of farmhouse adventures, creative endeavors, and scientific inquiries for the curious soul.
            </p>
        </div>
      </header>

      {/* Blog Grid */}
      <main className="max-w-7xl mx-auto py-20 px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {/* Post 1 - Farm */}
            <article onClick={() => onNavigate(ViewState.FARM_PROJECTS)} className="group cursor-pointer">
                <div className="aspect-[4/5] bg-[#e6e2d8] mb-6 overflow-hidden relative shadow-sm transition-shadow group-hover:shadow-xl">
                    <img
                        src="https://images.unsplash.com/photo-1592841200221-a6898f307baa?q=80&w=1974&auto=format&fit=crop"
                        alt="Tomatoes on Vine"
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 opacity-90 hover:opacity-100 grayscale-[20%] group-hover:grayscale-0"
                    />
                     <div className="absolute top-6 left-6 bg-[#f7f5f0]/95 px-4 py-2 text-[10px] tracking-[0.2em] font-sans uppercase border border-[#d4c5b0]">
                        Farm Projects
                    </div>
                </div>
                <div className="text-center md:text-left">
                    <h3 className="text-2xl mb-3 group-hover:text-[#8c7b64] transition-colors leading-snug">Heirloom Tomato Trellising</h3>
                    <p className="text-[#6b5d4d] font-sans text-sm leading-relaxed line-clamp-3 mb-4">
                        Discovering the most effective methods for supporting indeterminate varieties using cattle panels and natural twine to maximize harvest and minimize disease.
                    </p>
                    <span className="text-xs font-sans tracking-widest text-[#2c241b] border-b border-[#2c241b] pb-0.5 group-hover:text-[#8c7b64] group-hover:border-[#8c7b64] transition-all">READ MORE</span>
                </div>
            </article>

             {/* Post 2 - Art */}
             <article onClick={() => onNavigate(ViewState.ART_STUDIO)} className="group cursor-pointer">
                <div className="aspect-[4/5] bg-[#e6e2d8] mb-6 overflow-hidden relative shadow-sm transition-shadow group-hover:shadow-xl">
                    <img
                        src="https://images.unsplash.com/photo-1596395353526-9f76a5933c09?q=80&w=2070&auto=format&fit=crop"
                        alt="Dyed Fabric"
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 opacity-90 hover:opacity-100 grayscale-[20%] group-hover:grayscale-0"
                    />
                    <div className="absolute top-6 left-6 bg-[#f7f5f0]/95 px-4 py-2 text-[10px] tracking-[0.2em] font-sans uppercase border border-[#d4c5b0]">
                        Art Projects
                    </div>
                </div>
                <div className="text-center md:text-left">
                    <h3 className="text-2xl mb-3 group-hover:text-[#8c7b64] transition-colors leading-snug">Natural Dyeing with Marigolds</h3>
                    <p className="text-[#6b5d4d] font-sans text-sm leading-relaxed line-clamp-3 mb-4">
                        Extracting vibrant golden hues from our garden harvest to breathe new life into vintage linens. A step-by-step guide to mordanting and modifying colors.
                    </p>
                    <span className="text-xs font-sans tracking-widest text-[#2c241b] border-b border-[#2c241b] pb-0.5 group-hover:text-[#8c7b64] group-hover:border-[#8c7b64] transition-all">READ MORE</span>
                </div>
            </article>

             {/* Post 3 - Science */}
             <article onClick={() => onNavigate(ViewState.SCIENCE_LAB)} className="group cursor-pointer">
                <div className="aspect-[4/5] bg-[#e6e2d8] mb-6 overflow-hidden relative shadow-sm transition-shadow group-hover:shadow-xl">
                    <img
                        src="https://images.unsplash.com/photo-1463936575829-25148e1db1b8?q=80&w=2090&auto=format&fit=crop"
                        alt="Hydrangeas"
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 opacity-90 hover:opacity-100 grayscale-[20%] group-hover:grayscale-0"
                    />
                    <div className="absolute top-6 left-6 bg-[#f7f5f0]/95 px-4 py-2 text-[10px] tracking-[0.2em] font-sans uppercase border border-[#d4c5b0]">
                        Science Experiments
                    </div>
                </div>
                <div className="text-center md:text-left">
                    <h3 className="text-2xl mb-3 group-hover:text-[#8c7b64] transition-colors leading-snug">The pH of Soil & Hydrangeas</h3>
                    <p className="text-[#6b5d4d] font-sans text-sm leading-relaxed line-clamp-3 mb-4">
                        A backyard chemistry experiment to shift bloom colors from pink to blue using everyday kitchen ingredients. Understanding acidity in the garden.
                    </p>
                    <span className="text-xs font-sans tracking-widest text-[#2c241b] border-b border-[#2c241b] pb-0.5 group-hover:text-[#8c7b64] group-hover:border-[#8c7b64] transition-all">READ MORE</span>
                </div>
            </article>
        </div>

        {/* Categories Section */}
        <div className="mt-32 border-t border-[#e6e2d8] pt-20">
            <h2 className="text-center text-3xl md:text-4xl mb-16 italic text-[#4a4036] font-light">Explore the Curriculum</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
                 <div onClick={() => onNavigate(ViewState.FARM_PROJECTS)} className="p-10 border border-[#e6e2d8] hover:border-[#b0a08a] bg-white transition-all group hover:-translate-y-1 hover:shadow-lg cursor-pointer">
                    <Sprout className="w-8 h-8 mx-auto mb-6 text-[#8c7b64] group-hover:text-[#5e5040] transition-colors" />
                    <h4 className="text-lg font-bold mb-3 tracking-widest uppercase text-xs font-sans">Farm Projects</h4>
                    <p className="text-sm text-[#8c7b64] font-sans leading-relaxed">Permaculture, Animal Husbandry, and Seasonal Planting techniques for the modern homestead.</p>
                 </div>
                 <div onClick={() => onNavigate(ViewState.ART_STUDIO)} className="p-10 border border-[#e6e2d8] hover:border-[#b0a08a] bg-white transition-all group hover:-translate-y-1 hover:shadow-lg cursor-pointer">
                    <Palette className="w-8 h-8 mx-auto mb-6 text-[#8c7b64] group-hover:text-[#5e5040] transition-colors" />
                    <h4 className="text-lg font-bold mb-3 tracking-widest uppercase text-xs font-sans">Art Projects</h4>
                    <p className="text-sm text-[#8c7b64] font-sans leading-relaxed">Watercolor, Fiber Arts, and Pottery. Finding beauty in the imperfections of handmade goods.</p>
                 </div>
                 <div onClick={() => onNavigate(ViewState.SCIENCE_LAB)} className="p-10 border border-[#e6e2d8] hover:border-[#b0a08a] bg-white transition-all group hover:-translate-y-1 hover:shadow-lg cursor-pointer">
                    <FlaskConical className="w-8 h-8 mx-auto mb-6 text-[#8c7b64] group-hover:text-[#5e5040] transition-colors" />
                    <h4 className="text-lg font-bold mb-3 tracking-widest uppercase text-xs font-sans">Science Experiments</h4>
                    <p className="text-sm text-[#8c7b64] font-sans leading-relaxed">Botany, Chemistry, and Physics in the wild. Turning the backyard into a living laboratory.</p>
                 </div>
            </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-[#2c241b] text-[#f7f5f0] py-16 text-center font-sans">
        <div className="max-w-4xl mx-auto px-8">
            <div className="text-2xl font-serif tracking-[0.2em] mb-8 font-bold">DEAR ADELINE CO.</div>
            <div className="w-12 h-px bg-[#5e5040] mx-auto mb-8"></div>
            <div className="flex justify-center space-x-8 text-xs tracking-widest text-[#8c7b64] mb-8">
                <a href="#" className="hover:text-[#f7f5f0] transition-colors">INSTAGRAM</a>
                <a href="#" className="hover:text-[#f7f5f0] transition-colors">PINTEREST</a>
                <a href="#" className="hover:text-[#f7f5f0] transition-colors">CONTACT</a>
            </div>
            <p className="text-[#5e5040] text-[10px] tracking-wide">© {new Date().getFullYear()} DEAR ADELINE CO. ALL RIGHTS RESERVED.</p>
        </div>
      </footer>
    </div>
  );
};