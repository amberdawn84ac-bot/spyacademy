
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { SpellingList } from '../types';
import { Terminal, Lock, Play, RefreshCw, Volume2, ShieldCheck, Binary, Keyboard, Gamepad2, Ghost } from 'lucide-react';

interface SpellingGameProps {
  lists: SpellingList[];
  completedIds: string[];
  onComplete: (id: string) => void;
}

type GameMode = 'transcription' | 'scramble' | 'chomp';

// --- CHOMP GAME CONSTANTS ---
const TICK_RATE = 200; // ms per tick
const MAZE_MAP = [
"###################",
"#........#........#",
"#.###.##.#.##.###.#",
"#.................#",
"#.##.#.#####.#.##.#",
"#....#...#...#....#",
"####.###.#.###.####",
".........S.........",
"####.###.#.###.####",
"#....#...#...#....#",
"#.##.#.#####.#.##.#",
"#.................#",
"#.###.##.#.##.###.#",
"#........#........#",
"###################"
]; // 19x15 Grid

interface Coord { x: number; y: number; }
interface GameEntity extends Coord { dir: 'UP' | 'DOWN' | 'LEFT' | 'RIGHT' | null; color?: string; }
interface LetterItem extends Coord { char: string; index: number; collected: boolean; }

export const SpellingGame: React.FC<SpellingGameProps> = ({ lists, completedIds, onComplete }) => {
  const [selectedList, setSelectedList] = useState<SpellingList | null>(null);
  const [selectedMode, setSelectedMode] = useState<GameMode | null>(null);
  const [gameStatus, setGameStatus] = useState<'menu' | 'mode_select' | 'playing' | 'summary'>('menu');
  
  // Shared Game State
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  
  // -- TRANSCRIPTION / SCRAMBLE STATE --
  const [userInput, setUserInput] = useState('');
  const [feedback, setFeedback] = useState<'idle' | 'correct' | 'incorrect'>('idle');
  const [scrambleOrder, setScrambleOrder] = useState<number[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);

  // -- CHOMP GAME STATE --
  const [pacman, setPacman] = useState<GameEntity>({ x: 9, y: 7, dir: null });
  const [ghosts, setGhosts] = useState<GameEntity[]>([]);
  const [letters, setLetters] = useState<LetterItem[]>([]);
  const [chompNextIndex, setChompNextIndex] = useState(0); // Which letter index we need next
  const [isChompOver, setIsChompOver] = useState(false);

  // Refs for loop
  const requestRef = useRef<number>();
  const lastTickRef = useRef<number>(0);
  const directionRef = useRef<'UP' | 'DOWN' | 'LEFT' | 'RIGHT' | null>(null);

  // --- TTS Helper ---
  const speakWord = (text: string) => {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 0.8;
    window.speechSynthesis.speak(utterance);
  };

  // --- Initialization Logic ---

  const selectList = (list: SpellingList) => {
      setSelectedList(list);
      setGameStatus('mode_select');
  };

  const initGame = (mode: GameMode) => {
      if (!selectedList) return;
      setSelectedMode(mode);
      setGameStatus('playing');
      setCurrentIndex(0);
      setScore(0);
      resetRoundState(selectedList.words[0], mode);
  };

  const resetRoundState = (word: string, mode: GameMode) => {
      setUserInput('');
      setFeedback('idle');
      
      if (mode === 'transcription') {
          setTimeout(() => speakWord(word), 500);
      } else if (mode === 'scramble') {
          const indices = Array.from({length: word.length}, (_, i) => i);
          for (let i = indices.length - 1; i > 0; i--) {
              const j = Math.floor(Math.random() * (i + 1));
              [indices[i], indices[j]] = [indices[j], indices[i]];
          }
          setScrambleOrder(indices);
      } else if (mode === 'chomp') {
          // Play audio for Chomp mode too so they know what to spell
          setTimeout(() => speakWord(word), 500);
          initChompLevel(word);
      }
  };

  const initChompLevel = (word: string) => {
      setIsChompOver(false);
      setChompNextIndex(0);
      directionRef.current = null;
      
      // Find valid spots
      const validSpots: Coord[] = [];
      let startPos: Coord = { x: 9, y: 7 };

      MAZE_MAP.forEach((row, y) => {
          row.split('').forEach((cell, x) => {
              if (cell === '.') validSpots.push({x, y});
              if (cell === 'S') startPos = {x, y};
          });
      });

      // Shuffle spots
      for (let i = validSpots.length - 1; i > 0; i--) {
          const j = Math.floor(Math.random() * (i + 1));
          [validSpots[i], validSpots[j]] = [validSpots[j], validSpots[i]];
      }

      setPacman({ ...startPos, dir: null });

      // Place Letters
      const wordChars = word.toUpperCase().split('');
      const newLetters: LetterItem[] = wordChars.map((char, i) => ({
          char,
          index: i,
          collected: false,
          x: validSpots[i].x,
          y: validSpots[i].y
      }));
      setLetters(newLetters);

      // Place Ghosts (randomly after letters)
      const ghostColors = ['text-red-500', 'text-pink-500', 'text-cyan-500', 'text-orange-500'];
      const newGhosts: GameEntity[] = [];
      const numGhosts = Math.min(4, Math.max(1, Math.floor(word.length / 3) + 1)); // Scale difficulty
      
      for(let i=0; i<numGhosts; i++) {
          const spot = validSpots[word.length + i]; // Offset by letter count
          if (spot) {
              newGhosts.push({ ...spot, dir: 'UP', color: ghostColors[i % 4] });
          }
      }
      setGhosts(newGhosts);
  };

  // --- Logic: Progress ---

  const nextWord = () => {
      if (!selectedList || !selectedMode) return;
      
      if (currentIndex + 1 < selectedList.words.length) {
          const nextIndex = currentIndex + 1;
          setCurrentIndex(nextIndex);
          resetRoundState(selectedList.words[nextIndex], selectedMode);
      } else {
          finishGame();
      }
  };

  const finishGame = () => {
      setGameStatus('summary');
      if (selectedList && !completedIds.includes(selectedList.id)) {
          onComplete(selectedList.id);
      }
  };

  // --- Logic: Game 1 (Transcription) ---

  const checkTranscription = (e: React.FormEvent) => {
      e.preventDefault();
      if (!selectedList) return;
      const target = selectedList.words[currentIndex].toLowerCase();
      
      if (userInput.trim().toLowerCase() === target) {
          setFeedback('correct');
          setScore(s => s + 100);
          setTimeout(nextWord, 1000);
      } else {
          setFeedback('incorrect');
          speakWord("Try again. " + selectedList.words[currentIndex]);
      }
  };

  // --- Logic: Game 2 (Scramble) ---

  const handleScrambleClick = (char: string) => {
      if (feedback === 'correct') return;
      const current = userInput + char;
      setUserInput(current);
      
      const target = selectedList!.words[currentIndex].toLowerCase();
      
      if (current.length === target.length) {
          if (current === target) {
              setFeedback('correct');
              setScore(s => s + 100);
              setTimeout(nextWord, 1000);
          } else {
              setFeedback('incorrect');
              setTimeout(() => {
                  setUserInput(''); 
                  setFeedback('idle');
              }, 1000);
          }
      }
  };

  // --- Logic: Game 3 (Chomp / Pacman) ---

  const handleKeyDown = useCallback((e: KeyboardEvent) => {
      if (gameStatus !== 'playing' || selectedMode !== 'chomp') return;
      
      switch(e.key) {
          case 'ArrowUp': directionRef.current = 'UP'; break;
          case 'ArrowDown': directionRef.current = 'DOWN'; break;
          case 'ArrowLeft': directionRef.current = 'LEFT'; break;
          case 'ArrowRight': directionRef.current = 'RIGHT'; break;
      }
  }, [gameStatus, selectedMode]);

  useEffect(() => {
      window.addEventListener('keydown', handleKeyDown);
      return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleKeyDown]);

  const isValidMove = (x: number, y: number) => {
      if (y < 0 || y >= MAZE_MAP.length || x < 0 || x >= MAZE_MAP[0].length) return false;
      return MAZE_MAP[y][x] !== '#';
  };

  const moveEntity = (entity: GameEntity, intendedDir: string | null): GameEntity => {
      let dx = 0, dy = 0;
      let newDir = intendedDir;

      // Try intended direction
      if (intendedDir === 'UP') dy = -1;
      else if (intendedDir === 'DOWN') dy = 1;
      else if (intendedDir === 'LEFT') dx = -1;
      else if (intendedDir === 'RIGHT') dx = 1;

      if (intendedDir && isValidMove(entity.x + dx, entity.y + dy)) {
          return { ...entity, x: entity.x + dx, y: entity.y + dy, dir: intendedDir as any };
      }
      
      // If intended blocked, try keeping current direction? (For ghosts mostly)
      // For player, we just stop.
      return entity;
  };

  const chompGameLoop = useCallback((timestamp: number) => {
      if (!lastTickRef.current) lastTickRef.current = timestamp;
      const deltaTime = timestamp - lastTickRef.current;

      if (deltaTime >= TICK_RATE && !isChompOver) {
          // UPDATE GAME STATE
          setPacman(prev => {
              const next = moveEntity(prev, directionRef.current);
              return next;
          });

          // Move Ghosts
          setGhosts(prevGhosts => prevGhosts.map(g => {
             // Simple AI: Try to move towards player, else random
             const dirs = ['UP', 'DOWN', 'LEFT', 'RIGHT'];
             // Filter valid moves
             const validDirs = dirs.filter(d => {
                 let dx = 0, dy = 0;
                 if (d === 'UP') dy = -1;
                 else if (d === 'DOWN') dy = 1;
                 else if (d === 'LEFT') dx = -1;
                 else if (d === 'RIGHT') dx = 1;
                 return isValidMove(g.x + dx, g.y + dy);
             });
             
             if (validDirs.length === 0) return g;
             // Random choice for now to keep it chaotic but simple
             const choice = validDirs[Math.floor(Math.random() * validDirs.length)];
             return moveEntity(g, choice);
          }));

          lastTickRef.current = timestamp;
      }
      
      requestRef.current = requestAnimationFrame(chompGameLoop);
  }, [isChompOver]);

  // Handle Collisions & Game Logic separately to avoid loop complexity
  useEffect(() => {
      if (selectedMode !== 'chomp' || isChompOver) return;

      // 1. Check Letter Collection
      const letterAtPos = letters.find(l => l.x === pacman.x && l.y === pacman.y && !l.collected);
      if (letterAtPos) {
          if (letterAtPos.index === chompNextIndex) {
              // Correct Letter!
              setLetters(prev => prev.map(l => l.index === letterAtPos.index ? { ...l, collected: true } : l));
              setChompNextIndex(prev => prev + 1);
              setScore(s => s + 50);

              // Check Win
              if (chompNextIndex + 1 >= letters.length) {
                  setIsChompOver(true);
                  setFeedback('correct');
                  setTimeout(nextWord, 1500);
              }
          } else {
              // Wrong Letter - Penalty?
              // For now, just do nothing or maybe a visual shake
          }
      }

      // 2. Check Ghost Collision
      const hitGhost = ghosts.some(g => g.x === pacman.x && g.y === pacman.y);
      if (hitGhost) {
          // Die
          setIsChompOver(true);
          setFeedback('incorrect');
          setTimeout(() => {
              if (selectedList) initChompLevel(selectedList.words[currentIndex]);
              setFeedback('idle');
          }, 1500);
      }

  }, [pacman, ghosts, letters, chompNextIndex, selectedMode, isChompOver, selectedList, currentIndex]);

  useEffect(() => {
      if (gameStatus === 'playing' && selectedMode === 'chomp') {
          requestRef.current = requestAnimationFrame(chompGameLoop);
      }
      return () => cancelAnimationFrame(requestRef.current!);
  }, [gameStatus, selectedMode, chompGameLoop]);


  // --- RENDERERS ---

  if (gameStatus === 'menu') {
    return (
      <div className="h-full flex flex-col p-6 overflow-y-auto">
        <header className="mb-8 border-b border-emerald-900 pb-4">
            <h1 className="text-3xl font-mono text-emerald-500 mb-2 flex items-center gap-3">
                <Terminal className="w-8 h-8" />
                CRYPTOGRAPHY
            </h1>
            <p className="text-slate-400 font-mono text-sm">
                Select a frequency band (Week) to begin decryption protocols.
            </p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {lists.map(list => {
                const isComplete = completedIds.includes(list.id);
                return (
                    <button 
                        key={list.id}
                        onClick={() => selectList(list)}
                        className={`group relative p-6 rounded-lg border-2 text-left transition-all ${
                            isComplete 
                            ? 'bg-emerald-900/10 border-emerald-500/50 hover:bg-emerald-900/20' 
                            : 'bg-slate-900 border-slate-700 hover:border-emerald-500 hover:shadow-[0_0_20px_rgba(16,185,129,0.1)]'
                        }`}
                    >
                        <div className="flex justify-between items-start mb-4">
                            <span className="font-mono text-xs text-slate-500 uppercase tracking-widest">
                                WEEK {list.week}
                            </span>
                            {isComplete ? <ShieldCheck className="w-5 h-5 text-emerald-500" /> : <Lock className="w-5 h-5 text-slate-600 group-hover:text-emerald-400" />}
                        </div>
                        <h3 className={`text-xl font-bold mb-2 font-mono ${isComplete ? 'text-emerald-400' : 'text-white group-hover:text-emerald-400'}`}>
                            {list.title}
                        </h3>
                        <div className="flex items-center justify-between mt-4">
                            <span className="text-xs bg-slate-800 px-2 py-1 rounded text-slate-400 border border-slate-700">
                                {list.words.length} CODES
                            </span>
                            <span className="text-xs text-emerald-600 font-bold opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1">
                                SELECT <Play className="w-3 h-3 fill-current" />
                            </span>
                        </div>
                    </button>
                )
            })}
        </div>
      </div>
    );
  }

  if (gameStatus === 'mode_select' && selectedList) {
      return (
          <div className="h-full flex flex-col items-center justify-center p-6 space-y-8">
              <div className="text-center">
                  <h2 className="text-2xl font-bold text-white mb-2">Protocol Selection</h2>
                  <p className="text-slate-400">Target: {selectedList.title}</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full max-w-4xl">
                  <button onClick={() => initGame('transcription')} className="bg-slate-900 border border-slate-700 p-8 rounded-xl hover:border-emerald-500 hover:bg-slate-800 transition-all group text-left">
                      <Keyboard className="w-10 h-10 text-emerald-500 mb-4" />
                      <h3 className="text-xl font-bold text-white mb-2">Transcription</h3>
                      <p className="text-sm text-slate-400">Audio intercept analysis. Listen to the code word and transcribe it accurately.</p>
                  </button>

                  <button onClick={() => initGame('scramble')} className="bg-slate-900 border border-slate-700 p-8 rounded-xl hover:border-emerald-500 hover:bg-slate-800 transition-all group text-left">
                      <Binary className="w-10 h-10 text-blue-500 mb-4" />
                      <h3 className="text-xl font-bold text-white mb-2">Signal Reassembly</h3>
                      <p className="text-sm text-slate-400">Intercepted packets are fragmented. Reorder the signal fragments to reconstruct the key.</p>
                  </button>

                  <button onClick={() => initGame('chomp')} className="bg-slate-900 border border-slate-700 p-8 rounded-xl hover:border-emerald-500 hover:bg-slate-800 transition-all group text-left">
                      <Gamepad2 className="w-10 h-10 text-yellow-500 mb-4" />
                      <h3 className="text-xl font-bold text-white mb-2">Data Chomp</h3>
                      <p className="text-sm text-slate-400">Navigate the grid. Consume data packets in the correct sequence while avoiding countermeasures.</p>
                  </button>
              </div>
              
              <button onClick={() => setGameStatus('menu')} className="text-slate-500 hover:text-white text-sm">
                  CANCEL OPERATION
              </button>
          </div>
      )
  }

  // --- PLAYING STATE ---

  if (gameStatus === 'playing' && selectedList && selectedMode) {
      const currentWord = selectedList.words[currentIndex];
      const progress = ((currentIndex) / selectedList.words.length) * 100;

      return (
          <div className="h-full flex flex-col items-center justify-center p-6 bg-black relative overflow-hidden">
              {/* Overlay */}
              <div className="absolute inset-0 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] z-10 bg-[length:100%_2px,3px_100%] pointer-events-none"></div>
              
              <div className="z-20 w-full max-w-2xl">
                  {/* Header */}
                  <div className="flex justify-between items-end mb-2 text-emerald-500 font-mono text-sm">
                      <span>DECRYPTION_PROGRESS</span>
                      <span>{Math.round(progress)}%</span>
                  </div>
                  <div className="w-full h-1 bg-slate-800 mb-6">
                      <div className="h-full bg-emerald-500 transition-all duration-300" style={{width: `${progress}%`}}></div>
                  </div>

                  {/* GAME BOARD */}
                  <div className="border border-emerald-500/30 bg-emerald-900/5 p-4 rounded-lg relative min-h-[400px] flex flex-col items-center justify-center">
                      
                      {/* --- MODE 1: TRANSCRIPTION --- */}
                      {selectedMode === 'transcription' && (
                          <div className="text-center space-y-8 w-full">
                              <div className="text-slate-500 font-mono text-sm tracking-[0.2em] uppercase">Audio Intercept</div>
                              <button 
                                onClick={() => speakWord(currentWord)}
                                className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-emerald-500/10 border border-emerald-500/50 hover:bg-emerald-500/20 hover:scale-110 transition-all cursor-pointer group"
                              >
                                  <Volume2 className="w-10 h-10 text-emerald-400 group-hover:text-emerald-300" />
                              </button>
                              <form onSubmit={checkTranscription}>
                                  <input
                                      ref={inputRef}
                                      type="text"
                                      value={userInput}
                                      onChange={(e) => { setUserInput(e.target.value); setFeedback('idle'); }}
                                      autoComplete="off"
                                      autoFocus
                                      className={`w-full bg-transparent border-b-2 text-center text-4xl font-mono py-4 focus:outline-none transition-colors ${
                                          feedback === 'correct' ? 'border-emerald-500 text-emerald-400' : 
                                          feedback === 'incorrect' ? 'border-red-500 text-red-400' : 'border-slate-700 text-white'
                                      }`}
                                      placeholder="TYPE_HEARD_CODE"
                                  />
                              </form>
                          </div>
                      )}

                      {/* --- MODE 2: SCRAMBLE --- */}
                      {selectedMode === 'scramble' && (
                          <div className="text-center space-y-8 w-full">
                              <div className="text-slate-500 font-mono text-sm tracking-[0.2em] uppercase">Reassemble Signal</div>
                              
                              <div className="flex flex-wrap justify-center gap-3">
                                  {scrambleOrder.map((charIndex, i) => {
                                      const char = currentWord[charIndex];
                                      return (
                                          <button
                                              key={i}
                                              onClick={() => handleScrambleClick(char)}
                                              className="w-12 h-12 bg-slate-800 border border-slate-600 rounded text-xl font-bold text-white hover:bg-slate-700 active:scale-95 uppercase"
                                          >
                                              {char}
                                          </button>
                                      );
                                  })}
                              </div>

                              <div className={`text-4xl font-mono tracking-widest min-h-[3rem] border-b-2 ${feedback === 'incorrect' ? 'border-red-500 text-red-500' : (feedback === 'correct' ? 'border-emerald-500 text-emerald-500' : 'border-slate-700 text-white')}`}>
                                  {userInput}
                              </div>
                              
                              <button onClick={() => { setUserInput(''); setFeedback('idle'); }} className="text-xs text-slate-500 hover:text-white uppercase">
                                  Clear / Reset
                              </button>
                          </div>
                      )}

                      {/* --- MODE 3: CHOMP (Pacman) --- */}
                      {selectedMode === 'chomp' && (
                          <div className="flex flex-col items-center">
                              <div className="mb-4 flex items-center gap-4">
                                  <button 
                                      onClick={() => speakWord(currentWord)}
                                      className="p-2 rounded-full bg-emerald-500/10 border border-emerald-500/50 hover:bg-emerald-500/20 text-emerald-400"
                                      title="Replay Audio"
                                  >
                                      <Volume2 className="w-4 h-4" />
                                  </button>
                                  <div className="flex gap-2">
                                    {currentWord.split('').map((char, i) => (
                                        <span key={i} className={`w-8 h-8 flex items-center justify-center font-mono font-bold border ${
                                            i < chompNextIndex 
                                                ? 'bg-emerald-500 text-black border-emerald-500' 
                                                : 'bg-black text-slate-600 border-slate-800'
                                        }`}>
                                            {i < chompNextIndex ? char : '_'}
                                        </span>
                                    ))}
                                  </div>
                              </div>

                              <div className="relative bg-black p-1 border border-slate-800 rounded">
                                  {MAZE_MAP.map((row, y) => (
                                      <div key={y} className="flex">
                                          {row.split('').map((cell, x) => {
                                              const isWall = cell === '#';
                                              const hasPacman = pacman.x === x && pacman.y === y;
                                              const ghost = ghosts.find(g => g.x === x && g.y === y);
                                              const letter = letters.find(l => l.x === x && l.y === y && !l.collected);

                                              return (
                                                  <div key={`${x}-${y}`} className={`w-5 h-5 md:w-6 md:h-6 flex items-center justify-center ${isWall ? 'bg-blue-900/30 border border-blue-900/50' : ''}`}>
                                                      {/* Items */}
                                                      {!isWall && letter && (
                                                          <span className={`text-xs font-bold ${letter.index === chompNextIndex ? 'text-yellow-400 animate-pulse' : 'text-slate-600'}`}>
                                                              {letter.char}
                                                          </span>
                                                      )}
                                                      
                                                      {/* Entities */}
                                                      {hasPacman && (
                                                          <div className="absolute w-4 h-4 md:w-5 md:h-5 bg-yellow-400 rounded-full z-10 shadow-[0_0_10px_rgba(250,204,21,0.5)]">
                                                              {/* Mouth logic could go here, simple circle for now */}
                                                          </div>
                                                      )}
                                                      {ghost && (
                                                          <div className={`absolute w-4 h-4 md:w-5 md:h-5 z-10 ${ghost.color || 'text-red-500'}`}>
                                                              <Ghost className="w-full h-full fill-current" />
                                                          </div>
                                                      )}
                                                  </div>
                                              )
                                          })}
                                      </div>
                                  ))}
                                  
                                  {feedback === 'incorrect' && (
                                      <div className="absolute inset-0 bg-red-900/50 flex items-center justify-center backdrop-blur-sm">
                                          <div className="bg-black border border-red-500 text-red-500 px-6 py-4 font-mono font-bold animate-bounce">
                                              SYSTEM FAILURE
                                          </div>
                                      </div>
                                  )}
                              </div>
                              <div className="mt-4 text-xs text-slate-500 font-mono">Use ARROW KEYS to navigate</div>
                          </div>
                      )}
                  </div>
              </div>
          </div>
      );
  }

  // Summary View
  return (
      <div className="h-full flex flex-col items-center justify-center p-6 text-center">
          <div className="bg-slate-900 border border-emerald-900 p-12 rounded-xl max-w-lg w-full">
              <ShieldCheck className="w-16 h-16 text-emerald-500 mx-auto mb-6" />
              <h2 className="text-3xl font-bold text-white mb-2">Mission Accomplished</h2>
              <p className="text-slate-400 mb-8">All intelligence from {selectedList?.title} has been successfully decoded.</p>
              
              <div className="bg-black p-6 rounded mb-8 border border-slate-800">
                  <div className="text-4xl font-mono text-emerald-400 mb-1">{score}</div>
                  <div className="text-xs text-slate-500 uppercase tracking-widest">Mission Score</div>
              </div>

              <div className="flex gap-4 justify-center">
                  <button 
                    onClick={() => setGameStatus('menu')}
                    className="px-6 py-3 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-bold transition-all"
                  >
                      RETURN TO BASE
                  </button>
                  <button 
                    onClick={() => {
                        if (selectedList && selectedMode) {
                            initGame(selectedMode);
                        }
                    }}
                    className="px-6 py-3 rounded border border-slate-700 hover:bg-slate-800 text-slate-300 font-bold transition-all flex items-center gap-2"
                  >
                      <RefreshCw className="w-4 h-4" /> REPLAY
                  </button>
              </div>
          </div>
      </div>
  );
};
