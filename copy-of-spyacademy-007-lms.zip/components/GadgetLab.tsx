import React, { useState } from 'react';
import { fabricateGadget, checkApiKeySelection, promptApiKeySelection } from '../services/geminiService';
import { Cpu, Zap, Download, Loader2 } from 'lucide-react';

export const GadgetLab: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [size, setSize] = useState<'1K' | '2K' | '4K'>('1K');
  const [loading, setLoading] = useState(false);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt) return;

    const hasKey = await checkApiKeySelection();
    if (!hasKey) {
        await promptApiKeySelection();
        return;
    }

    setLoading(true);
    try {
      const imageUrl = await fabricateGadget(prompt, size);
      setGeneratedImage(imageUrl);
    } catch (err) {
      console.error(err);
      alert("Fabrication error: Resource unavailable.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="h-full flex flex-col md:flex-row gap-8">
      {/* Controls */}
      <div className="w-full md:w-1/3 bg-slate-900 border border-slate-800 rounded-xl p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="p-2 bg-emerald-500/10 rounded-lg">
            <Cpu className="w-6 h-6 text-emerald-500" />
          </div>
          <h2 className="text-xl font-bold text-white">Q-Branch Fabricator</h2>
        </div>

        <form onSubmit={handleGenerate} className="space-y-6">
          <div>
            <label className="block text-xs font-mono text-slate-400 uppercase mb-2">Gadget Schematic Description</label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="e.g., A wristwatch with a hidden laser cutter and grappling hook, schematic blueprint style..."
              className="w-full h-32 bg-black border border-slate-700 rounded-lg p-3 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-emerald-500 transition-colors resize-none"
            />
          </div>

          <div>
             <label className="block text-xs font-mono text-slate-400 uppercase mb-2">Resolution Output</label>
             <div className="grid grid-cols-3 gap-2">
                {(['1K', '2K', '4K'] as const).map((s) => (
                    <button
                        key={s}
                        type="button"
                        onClick={() => setSize(s)}
                        className={`py-2 px-3 rounded text-sm font-bold transition-all ${
                            size === s 
                            ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-900/20' 
                            : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                        }`}
                    >
                        {s}
                    </button>
                ))}
             </div>
          </div>

          <button
            type="submit"
            disabled={loading || !prompt}
            className="w-full py-4 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-lg shadow-lg transform active:scale-[0.98] transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
          >
            {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Zap className="w-5 h-5" />}
            <span>FABRICATE PROTOTYPE</span>
          </button>
        </form>
      </div>

      {/* Output */}
      <div className="w-full md:w-2/3 bg-black rounded-xl border border-slate-800 relative overflow-hidden flex items-center justify-center">
        <div className="absolute inset-0 bg-[linear-gradient(rgba(16,185,129,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(16,185,129,0.03)_1px,transparent_1px)] bg-[size:40px_40px]"></div>
        
        {generatedImage ? (
          <div className="relative group w-full h-full flex items-center justify-center p-8">
            <img 
                src={generatedImage} 
                alt="Generated Gadget" 
                className="max-w-full max-h-full object-contain rounded shadow-2xl shadow-emerald-900/20" 
            />
            <div className="absolute bottom-6 right-6 opacity-0 group-hover:opacity-100 transition-opacity">
                <a 
                    href={generatedImage} 
                    download={`gadget-${Date.now()}.png`}
                    className="flex items-center space-x-2 bg-slate-900/90 text-white px-4 py-2 rounded-full border border-slate-700 hover:border-emerald-500 backdrop-blur-sm"
                >
                    <Download className="w-4 h-4" />
                    <span className="text-sm">Save Schematic</span>
                </a>
            </div>
          </div>
        ) : (
          <div className="text-center z-10 opacity-30">
            <Cpu className="w-16 h-16 mx-auto mb-4 text-emerald-500" />
            <p className="font-mono text-emerald-500">WAITING FOR INPUT...</p>
          </div>
        )}
      </div>
    </div>
  );
};