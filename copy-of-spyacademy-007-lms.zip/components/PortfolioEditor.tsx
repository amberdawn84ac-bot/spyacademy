
import React, { useState, useEffect } from 'react';
import { BaseContent, PortfolioEntry } from '../types';
import { Save, Upload, X, Image as ImageIcon, Calendar } from 'lucide-react';

interface PortfolioEditorProps {
  item: BaseContent;
  initialEntry?: PortfolioEntry;
  onSave: (entryId: string | number, entry: PortfolioEntry) => void;
  onClose: () => void;
}

export const PortfolioEditor: React.FC<PortfolioEditorProps> = ({ item, initialEntry, onSave, onClose }) => {
  const [reflection, setReflection] = useState(initialEntry?.reflection || '');
  const [images, setImages] = useState<string[]>(initialEntry?.images || []);
  
  // Auto-generate a "What I learned" starter if empty
  useEffect(() => {
    if (!reflection) {
      setReflection(`## Project Report: ${item.title}\n\n**What I Learned:**\n\n**Challenges I Overcame:**\n\n`);
    }
  }, [item, reflection]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImages(prev => [...prev, reader.result as string]);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = () => {
    const entry: PortfolioEntry = {
      reflection,
      images,
      date: initialEntry?.date || new Date().toISOString()
    };
    onSave(item.id, entry);
  };

  return (
    <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-3xl rounded-xl shadow-2xl flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-6 border-b border-slate-800 flex justify-between items-start bg-slate-950 rounded-t-xl">
          <div>
            <div className="flex items-center space-x-2 text-emerald-500 mb-1">
               <span className="text-xs font-mono uppercase tracking-widest">Graduation Portfolio Entry</span>
            </div>
            <h2 className="text-2xl font-bold text-white">{item.title}</h2>
            <div className="flex items-center space-x-4 mt-2 text-xs text-slate-400 font-mono">
                <span className="flex items-center space-x-1">
                    <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                    <span>SUBJECT: {item.subject.toUpperCase()}</span>
                </span>
                <span className="flex items-center space-x-1">
                    <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                    <span>CREDITS EARNED: {item.credits}</span>
                </span>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-500 hover:text-white transition-colors">
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          
          {/* Reflection */}
          <div>
            <label className="block text-sm font-bold text-slate-300 mb-2 uppercase tracking-wide">Field Notes & Reflection</label>
            <textarea
              value={reflection}
              onChange={(e) => setReflection(e.target.value)}
              className="w-full h-48 bg-slate-950 border border-slate-700 rounded-lg p-4 text-slate-200 focus:outline-none focus:border-emerald-500 transition-colors font-mono text-sm leading-relaxed"
              placeholder="Record your observations, what you created, and what you learned..."
            />
          </div>

          {/* Evidence Upload */}
          <div>
            <label className="block text-sm font-bold text-slate-300 mb-4 uppercase tracking-wide">Mission Evidence</label>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
               {images.map((img, idx) => (
                 <div key={idx} className="relative aspect-square group rounded-lg overflow-hidden border border-slate-700">
                    <img src={img} alt="Evidence" className="w-full h-full object-cover" />
                    <button 
                        onClick={() => setImages(images.filter((_, i) => i !== idx))}
                        className="absolute top-1 right-1 bg-red-500 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                        <X className="w-3 h-3" />
                    </button>
                 </div>
               ))}

               <label className="aspect-square border-2 border-dashed border-slate-700 hover:border-emerald-500 rounded-lg flex flex-col items-center justify-center cursor-pointer transition-colors group">
                  <Upload className="w-6 h-6 text-slate-500 group-hover:text-emerald-500 mb-2" />
                  <span className="text-[10px] text-slate-500 uppercase font-bold">Add Photo</span>
                  <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
               </label>
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="p-6 border-t border-slate-800 bg-slate-950 rounded-b-xl flex justify-between items-center">
            <div className="flex items-center space-x-2 text-slate-500 text-xs">
                <Calendar className="w-3 h-3" />
                <span>{new Date().toLocaleDateString()}</span>
            </div>
            <div className="flex space-x-3">
                <button onClick={onClose} className="px-4 py-2 text-slate-400 hover:text-white text-sm font-bold">CANCEL</button>
                <button 
                    onClick={handleSave}
                    className="flex items-center space-x-2 bg-emerald-600 hover:bg-emerald-500 text-white px-6 py-2 rounded-lg font-bold shadow-lg shadow-emerald-900/50 transition-transform active:scale-95"
                >
                    <Save className="w-4 h-4" />
                    <span>SAVE TO PORTFOLIO</span>
                </button>
            </div>
        </div>
      </div>
    </div>
  );
};
