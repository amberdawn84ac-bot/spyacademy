

export type UserRole = 'admin' | 'student';

export type Subject = 'English' | 'Math' | 'Science' | 'History' | 'Arts' | 'Electives' | 'Technology';

export interface User {
  id: string;
  username: string;
  role: UserRole;
  name: string;
  avatar?: string;
  password?: string;
}

export interface BaseContent {
  id: string | number;
  title: string;
  subject: Subject;
  credits: number; // 1.0 = Full Year, 0.5 = Semester, etc.
}

export interface Mission extends BaseContent {
  id: string; // Override for specific type
  week: number;
  category: string;
  description: string;
  content: string;
  status: 'locked' | 'active' | 'completed';
}

export interface Project extends BaseContent {
  image: string;
  wowFactor: string; // Description/Observation
  concepts: string[];
  connection: string;
  materials: string[];
  instructions: { title?: string, steps: string[] }[];
  safety: string[];
}

export interface SpellingList extends BaseContent {
  id: string;
  week: number;
  words: string[];
  difficulty: 'Level 1' | 'Level 2' | 'Level 3';
  gradeLevel: number;
}

export interface PortfolioEntry {
  reflection: string;
  images: string[];
  date: string;
}

export interface StudentProgress {
  studentId: string;
  completedMissionIds: string[];
  completedProjectIds: (string | number)[]; // IDs of completed art/science/farm projects
  completedSpellingIds: string[]; // IDs of completed spelling lists
  portfolioItems: Record<string, PortfolioEntry>; // contentId -> Entry
}

export interface Student extends User {
  grade: number;
  progress: StudentProgress;
}

export enum ViewState {
  LANDING = 'LANDING',
  LOGIN = 'LOGIN',
  DASHBOARD = 'DASHBOARD',
  MISSION_CONTROL = 'MISSION_CONTROL', 
  GADGET_LAB = 'GADGET_LAB', 
  SCIENCE_LAB = 'SCIENCE_LAB', 
  ART_STUDIO = 'ART_STUDIO', 
  FARM_PROJECTS = 'FARM_PROJECTS', 
  CRYPTOGRAPHY = 'CRYPTOGRAPHY',
  SECURE_LINE = 'SECURE_LINE',
  PORTFOLIO = 'PORTFOLIO',
  RECRUIT_TRACKER = 'RECRUIT_TRACKER', 
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  sources?: { uri: string; title: string }[];
}

export interface GeneratedImage {
  url: string;
  prompt: string;
}
