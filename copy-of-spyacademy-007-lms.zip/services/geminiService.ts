import { GoogleGenAI, Modality, LiveServerMessage } from "@google/genai";

// --- Helpers ---

// Helper to check for API key selection (required for Pro Image)
export const checkApiKeySelection = async (): Promise<boolean> => {
  if (typeof window !== 'undefined' && (window as any).aistudio) {
    return await (window as any).aistudio.hasSelectedApiKey();
  }
  return !!process.env.API_KEY;
};

export const promptApiKeySelection = async () => {
  if (typeof window !== 'undefined' && (window as any).aistudio) {
    await (window as any).aistudio.openSelectKey();
  }
};

// --- Features ---

// 1. Image Generation (Gadget Lab)
export const fabricateGadget = async (prompt: string, size: '1K' | '2K' | '4K') => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  // Using generateContent for gemini-3-pro-image-preview
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-image-preview',
    contents: {
      parts: [{ text: prompt }],
    },
    config: {
      imageConfig: {
        aspectRatio: "1:1",
        imageSize: size
      }
    },
  });

  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      return `data:image/png;base64,${part.inlineData.data}`;
    }
  }
  throw new Error("No image generated");
};

// 2. Intel Gathering (Search Grounding)
export const gatherIntel = async (prompt: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: prompt,
    config: {
      tools: [{googleSearch: {}}],
    },
  });
  
  return {
    text: response.text,
    groundingChunks: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
  };
};

// 3. Secure Line (Live API)

// Helper to decode audio
function decodeAudio(base64: string): ArrayBuffer {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes.buffer;
}

export const connectSecureLine = async (
    onAudioData: (buffer: ArrayBuffer) => void,
    onDisconnect: () => void,
    systemInstruction?: string
) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  // Using the Live API
  return await ai.live.connect({
    model: 'gemini-2.5-flash-native-audio-preview-09-2025',
    callbacks: {
      onopen: () => {
        console.log("Secure Line Uplink Established");
      },
      onmessage: (message: LiveServerMessage) => {
        // Handle Audio
        const base64Audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
        if (base64Audio) {
            onAudioData(decodeAudio(base64Audio));
        }
      },
      onclose: () => {
        console.log("Secure Line Uplink Terminated");
        onDisconnect();
      },
      onerror: (err) => {
        console.error("Secure Line Error:", err);
        onDisconnect();
      }
    },
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Fenrir' } }
      },
      systemInstruction: systemInstruction || "You are 'M', the Chief of Intelligence. We are on a secure voice line. Your responses should be brief, authoritative, and helpful to the agent in the field. Do not ramble. End transmissions with 'Over' occasionally.",
    }
  });
};