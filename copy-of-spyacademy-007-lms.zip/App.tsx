
import React, { useState, useMemo, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { MissionControl } from './components/MissionControl';
import { GadgetLab } from './components/GadgetLab';
import { Login } from './components/Login';
import { RecruitTracker } from './components/RecruitTracker';
import { LandingPage } from './components/LandingPage';
import { ScienceLab } from './components/ScienceLab';
import { ArtStudio } from './components/ArtStudio';
import { FarmProjects } from './components/FarmProjects';
import { PortfolioEditor } from './components/PortfolioEditor';
import { SpellingGame } from './components/SpellingGame';
import { SecureLine } from './components/SecureLine';
import { DataUplink } from './components/DataUplink';
import { ViewState, Mission, User, Student, Subject, BaseContent, PortfolioEntry, StudentProgress, Project } from './types';
import { CURRICULUM, MOCK_STUDENTS, INITIAL_ART_PROJECTS, INITIAL_FARM_PROJECTS, INITIAL_SCIENCE_EXPERIMENTS, SPELLING_CURRICULUM } from './data';
import { CheckCircle, Circle, Award, BookOpen, GraduationCap, FileText, Image as ImageIcon } from 'lucide-react';

const STORAGE_KEY = 'spy_academy_data_v1';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [currentView, setCurrentView] = useState<ViewState>(ViewState.LANDING);
  
  // State for content (Admin editable)
  const [missions, setMissions] = useState<Mission[]>(CURRICULUM);
  const [artProjects, setArtProjects] = useState<Project[]>(INITIAL_ART_PROJECTS as unknown as Project[]);
  const [scienceExperiments, setScienceExperiments] = useState<Project[]>(INITIAL_SCIENCE_EXPERIMENTS as unknown as Project[]);
  const [farmProjects, setFarmProjects] = useState<Project[]>(INITIAL_FARM_PROJECTS as unknown as Project[]);

  // State for students - Initialized from LocalStorage if available
  const [students, setStudents] = useState<Student[]>(() => {
    try {
        const saved = localStorage.getItem(STORAGE_KEY);
        if (saved) {
            return JSON.parse(saved);
        }
    } catch (e) {
        console.error("Failed to load recruits from storage", e);
    }
    return MOCK_STUDENTS as Student[];
  });

  // State for Sync Modal
  const [isSyncOpen, setIsSyncOpen] = useState(false);

  // Save students to LocalStorage whenever they change
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(students));
  }, [students]);

  // Handle restoring data from file
  const handleImportData = (importedStudents: Student[]) => {
      setStudents(importedStudents);
      // If current user is in the imported list, update them, otherwise logout to prevent state mismatch
      if (user) {
          const updatedUser = importedStudents.find(s => s.id === user.id);
          if (updatedUser) {
              // Update user object if needed, though mostly we rely on the students array
          } else if (user.role !== 'admin') {
              // User no longer exists in new dataset
              handleLogout();
          }
      }
      alert("Database updated successfully.");
  };

  // Portfolio Modal State
  const [isPortfolioOpen, setIsPortfolioOpen] = useState(false);
  const [activePortfolioItem, setActivePortfolioItem] = useState<BaseContent | null>(null);

  // Derived state for current user's progress
  const currentUserProgress = useMemo((): StudentProgress => {
     return students.find(s => s.id === user?.id)?.progress || { 
         studentId: user?.id || '',
         completedMissionIds: [], 
         completedProjectIds: [], 
         completedSpellingIds: [],
         portfolioItems: {} 
     };
  }, [students, user]);

  // Helper to find content by ID for the portfolio editor
  const findContentById = (id: string | number): BaseContent | undefined => {
      const allContent = [...missions, ...artProjects, ...scienceExperiments, ...farmProjects, ...SPELLING_CURRICULUM];
      // Loose equality check for string vs number IDs
      // @ts-ignore
      return allContent.find(c => c.id == id) as unknown as BaseContent; 
  };

  const handleLogin = (loggedInUser: User) => {
    setUser(loggedInUser);
    setCurrentView(loggedInUser.role === 'admin' ? ViewState.RECRUIT_TRACKER : ViewState.DASHBOARD);
  };

  const handleSignup = (name: string, username: string, grade: number, password?: string) => {
      const id = `agent-${Date.now()}`;
      const newUser: Student = {
          id: id,
          name,
          username,
          password,
          role: 'student',
          grade,
          progress: {
              studentId: id,
              completedMissionIds: [],
              completedProjectIds: [],
              completedSpellingIds: [],
              portfolioItems: {}
          }
      };
      setStudents(prev => [...prev, newUser]);
      handleLogin(newUser);
  };

  const handleLogout = () => {
    setUser(null);
    setCurrentView(ViewState.LANDING);
  };

  // Generic completion handler that marks item complete AND opens portfolio
  const handleCompleteItem = (id: string | number, type: 'mission' | 'project' | 'spelling') => {
      if (user?.role !== 'student') return;

      // 1. Update Progress
      setStudents(prev => prev.map(s => {
        if (s.id === user.id) {
            const newProgress = { ...s.progress };
            if (type === 'mission') {
                newProgress.completedMissionIds = [...new Set([...s.progress.completedMissionIds, String(id)])];
            } else if (type === 'spelling') {
                newProgress.completedSpellingIds = [...new Set([...s.progress.completedSpellingIds, String(id)])];
            } else {
                newProgress.completedProjectIds = [...new Set([...(s.progress.completedProjectIds || []), id])];
            }
            return { ...s, progress: newProgress };
        }
        return s;
      }));

      // 2. Open Portfolio Editor immediately
      const item = findContentById(id);
      if (item) {
          setActivePortfolioItem(item);
          setIsPortfolioOpen(true);
      }
  };

  const handleSavePortfolioEntry = (entryId: string | number, entry: PortfolioEntry) => {
      setStudents(prev => prev.map(s => {
          if (s.id === user?.id) {
              return {
                  ...s,
                  progress: {
                      ...s.progress,
                      portfolioItems: {
                          ...s.progress.portfolioItems,
                          [String(entryId)]: entry
                      }
                  }
              };
          }
          return s;
      }));
      setIsPortfolioOpen(false);
      setActivePortfolioItem(null);
  };

  const handleCompleteMission = (id: string) => handleCompleteItem(id, 'mission');
  const handleCompleteProject = (id: number | string) => handleCompleteItem(id, 'project');
  const handleCompleteSpelling = (id: string) => handleCompleteItem(id, 'spelling');

  const handleUpdateMissions = (updated: Mission[]) => setMissions(updated);
  
  // Explicit casting for generic Project updates
  const handleUpdateArt = (updated: any[]) => setArtProjects(updated as Project[]);
  const handleUpdateScience = (updated: any[]) => setScienceExperiments(updated as Project[]);
  const handleUpdateFarm = (updated: any[]) => setFarmProjects(updated as Project[]);

  // Dashboard Component
  const Dashboard = () => {
    const REQUIREMENTS: { subject: Subject; required: number }[] = [
        { subject: 'English', required: 4 },
        { subject: 'Math', required: 3 },
        { subject: 'Science', required: 3 },
        { subject: 'History', required: 3 },
        { subject: 'Arts', required: 1 },
        { subject: 'Technology', required: 1 },
        { subject: 'Electives', required: 8 }
    ];

    const getCredits = (subject: Subject): { current: number; completedItems: BaseContent[] } => {
        let current = 0;
        let completedItems: BaseContent[] = [];

        missions.forEach(m => {
            if (currentUserProgress.completedMissionIds.includes(m.id) && m.subject === subject) {
                current += m.credits;
                completedItems.push(m);
            }
        });
        
        const allProjects = [...artProjects, ...scienceExperiments, ...farmProjects];
        allProjects.forEach(p => {
             // @ts-ignore
             if (currentUserProgress.completedProjectIds?.includes(p.id) && p.subject === subject) {
                 // @ts-ignore
                 current += p.credits;
                 completedItems.push(p as unknown as BaseContent);
             }
        });

        // Add Spelling Lists
        SPELLING_CURRICULUM.forEach(s => {
            if (currentUserProgress.completedSpellingIds.includes(s.id) && s.subject === subject) {
                current += s.credits;
                completedItems.push(s);
            }
        });

        return { current: parseFloat(current.toFixed(2)), completedItems };
    };

    return (
      <div className="space-y-8 animate-in fade-in duration-500 h-full overflow-y-auto pr-4 custom-scrollbar">
        <header>
            <h1 className="text-4xl font-bold text-white mb-2">Graduation Tracker</h1>
            <p className="text-slate-400">Oklahoma Standard Diploma Requirements // Student: {user?.name}</p>
        </header>

        <div className="grid grid-cols-1 gap-6">
            {REQUIREMENTS.map(req => {
                const { current, completedItems } = getCredits(req.subject);
                const progress = Math.min(100, (current / req.required) * 100);
                const isComplete = current >= req.required;

                return (
                    <div key={req.subject} className="bg-slate-900 rounded-xl border border-slate-800 p-6">
                        <div className="flex justify-between items-center mb-4">
                            <div className="flex items-center space-x-3">
                                <div className={`p-2 rounded-lg ${isComplete ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-800 text-slate-400'}`}>
                                    {req.subject === 'English' && <BookOpen className="w-6 h-6" />}
                                    {req.subject === 'Math' && <div className="font-mono font-bold text-lg">∑</div>}
                                    {req.subject === 'Science' && <div className="font-mono font-bold text-lg">⚛</div>}
                                    {req.subject === 'History' && <div className="font-mono font-bold text-lg">🏛</div>}
                                    {req.subject === 'Arts' && <div className="font-mono font-bold text-lg">🎨</div>}
                                    {req.subject === 'Technology' && <div className="font-mono font-bold text-lg">💻</div>}
                                    {req.subject === 'Electives' && <div className="font-mono font-bold text-lg">⚡</div>}
                                </div>
                                <div>
                                    <h3 className="text-xl font-bold text-white">{req.subject}</h3>
                                    <p className="text-xs text-slate-500 uppercase tracking-widest">{current} / {req.required} UNITS EARNED</p>
                                </div>
                            </div>
                            <div className="text-right">
                                {isComplete ? (
                                    <div className="flex items-center space-x-2 text-emerald-500">
                                        <CheckCircle className="w-6 h-6" />
                                        <span className="font-bold">COMPLETE</span>
                                    </div>
                                ) : (
                                    <span className="text-slate-500 font-mono">{progress.toFixed(0)}%</span>
                                )}
                            </div>
                        </div>

                        <div className="w-full h-3 bg-slate-950 rounded-full overflow-hidden border border-slate-800 mb-6">
                            <div 
                                className={`h-full transition-all duration-1000 ease-out ${isComplete ? 'bg-emerald-500' : 'bg-amber-500'}`}
                                style={{ width: `${progress}%` }}
                            ></div>
                        </div>

                        {completedItems.length > 0 ? (
                            <div className="bg-slate-950/50 rounded p-4">
                                <h4 className="text-[10px] text-slate-500 uppercase font-bold mb-3 tracking-wider">Completed Requirements</h4>
                                <div className="space-y-2">
                                    {completedItems.map((item, idx) => (
                                        <div key={idx} className="flex justify-between items-center text-sm border-b border-slate-800/50 pb-2 last:border-0 last:pb-0">
                                            <span className="text-slate-300 truncate pr-4">{item.title}</span>
                                            <div className="flex items-center space-x-4">
                                                <button 
                                                    onClick={() => {
                                                        setActivePortfolioItem(item);
                                                        setIsPortfolioOpen(true);
                                                    }}
                                                    className="text-xs text-slate-500 hover:text-white underline"
                                                >
                                                    View Portfolio
                                                </button>
                                                <span className="text-emerald-500 font-mono text-xs whitespace-nowrap">+{item.credits} Units</span>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        ) : (
                            <p className="text-xs text-slate-600 italic px-2">No credits earned yet.</p>
                        )}
                    </div>
                );
            })}
        </div>
      </div>
    );
  };

  const Portfolio = () => {
    // Explicit cast to fix 'unknown' type error in map
    const portfolioEntries = Object.entries(currentUserProgress.portfolioItems) as [string, PortfolioEntry][];

    return (
      <div className="flex flex-col h-full space-y-6">
          <div className="text-center">
             <h2 className="text-3xl font-bold text-white mb-2">Agent Dossier</h2>
             <p className="text-slate-400">Secure record of completed operations.</p>
          </div>
          
          {portfolioEntries.length === 0 ? (
             <div className="flex-1 flex flex-col items-center justify-center text-slate-500">
                 <div className="w-24 h-24 bg-slate-900 rounded-full flex items-center justify-center border-2 border-dashed border-slate-700 mb-4">
                    <FileText className="w-10 h-10" />
                 </div>
                 <p>No portfolio entries filed. Complete missions or projects to begin.</p>
             </div>
          ) : (
             <div className="grid grid-cols-1 gap-6 overflow-y-auto pb-8">
                 {portfolioEntries.map(([id, entry]) => {
                     const content = findContentById(id);
                     if (!content) return null;
                     
                     return (
                         <div key={id} className="bg-slate-900 rounded-xl border border-slate-800 p-6 flex flex-col md:flex-row gap-6">
                             <div className="flex-1">
                                 <div className="flex justify-between items-start mb-4">
                                    <div>
                                        <h3 className="text-xl font-bold text-white">{content.title}</h3>
                                        <div className="flex items-center space-x-2 text-xs text-slate-500 mt-1">
                                            <span className="bg-emerald-900/30 text-emerald-400 px-2 py-0.5 rounded uppercase">{content.subject}</span>
                                            <span>•</span>
                                            <span>{new Date(entry.date).toLocaleDateString()}</span>
                                        </div>
                                    </div>
                                    <button 
                                        onClick={() => {
                                            setActivePortfolioItem(content);
                                            setIsPortfolioOpen(true);
                                        }}
                                        className="text-xs text-slate-400 hover:text-white underline"
                                    >
                                        Edit Entry
                                    </button>
                                 </div>
                                 <div className="prose prose-invert prose-sm text-slate-300 max-h-40 overflow-hidden relative">
                                     <p className="whitespace-pre-wrap">{entry.reflection}</p>
                                     <div className="absolute bottom-0 left-0 w-full h-8 bg-gradient-to-t from-slate-900 to-transparent"></div>
                                 </div>
                             </div>
                             {entry.images.length > 0 && (
                                 <div className="w-full md:w-48 flex-shrink-0">
                                     <div className="aspect-video bg-black rounded-lg overflow-hidden border border-slate-700 relative group">
                                         <img src={entry.images[0]} alt="Evidence" className="w-full h-full object-cover" />
                                         <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                             <div className="flex items-center space-x-1 text-white text-xs font-bold">
                                                 <ImageIcon className="w-4 h-4" />
                                                 <span>{entry.images.length} Image{entry.images.length > 1 ? 's' : ''}</span>
                                             </div>
                                         </div>
                                     </div>
                                 </div>
                             )}
                         </div>
                     );
                 })}
             </div>
          )}
      </div>
    );
  };

  // Render Portfolio Overlay
  const renderPortfolioOverlay = () => {
      if (isPortfolioOpen && activePortfolioItem) {
          return (
              <PortfolioEditor 
                  item={activePortfolioItem}
                  initialEntry={currentUserProgress.portfolioItems[activePortfolioItem.id]}
                  onSave={handleSavePortfolioEntry}
                  onClose={() => {
                      setIsPortfolioOpen(false);
                      setActivePortfolioItem(null);
                  }}
              />
          );
      }
      return null;
  };

  // 1. Landing Page (Public Home) - Accessible by everyone
  if (currentView === ViewState.LANDING) {
    return (
        <LandingPage 
            onNavigate={(view) => {
                if (user && view === ViewState.LOGIN) {
                    setCurrentView(user.role === 'admin' ? ViewState.RECRUIT_TRACKER : ViewState.DASHBOARD);
                } else {
                    setCurrentView(view);
                }
            }} 
        />
    );
  }

  // 2. Unauthenticated Routes
  if (!user) {
      if (currentView === ViewState.LOGIN) return (
        <>
            <Login 
                onLogin={handleLogin} 
                onSignup={handleSignup} 
                existingStudents={students} 
                onSync={() => setIsSyncOpen(true)}
            />
            {isSyncOpen && <DataUplink data={students} onImport={handleImportData} onClose={() => setIsSyncOpen(false)} />}
        </>
      );
      if (currentView === ViewState.FARM_PROJECTS) return (
        // @ts-ignore
        <FarmProjects onNavigate={setCurrentView} projects={farmProjects} user={null} onUpdate={() => {}} variant="public" />
      );
      if (currentView === ViewState.ART_STUDIO) return (
        // @ts-ignore
        <ArtStudio onNavigate={setCurrentView} projects={artProjects} user={null} onUpdate={() => {}} variant="public" />
      );
      if (currentView === ViewState.SCIENCE_LAB) return (
        // @ts-ignore
        <ScienceLab onNavigate={setCurrentView} experiments={scienceExperiments} user={null} onUpdate={() => {}} variant="public" />
      );
      
      // Fallback
      return <LandingPage onNavigate={setCurrentView} />;
  }

  // 3. Authenticated Routes (Dashboard Layout)
  return (
    <div className="flex min-h-screen bg-black">
      {isSyncOpen && <DataUplink data={students} onImport={handleImportData} onClose={() => setIsSyncOpen(false)} />}
      {renderPortfolioOverlay()}
      <Sidebar 
        currentView={currentView} 
        onNavigate={setCurrentView} 
        user={user}
        onLogout={handleLogout}
      />
      
      <main className="flex-1 ml-64 p-8 h-screen overflow-hidden">
        <div className="max-w-7xl mx-auto h-full">
            {currentView === ViewState.DASHBOARD && <Dashboard />}
            {currentView === ViewState.MISSION_CONTROL && (
                <MissionControl 
                    missions={missions} 
                    artProjects={artProjects}
                    scienceExperiments={scienceExperiments}
                    farmProjects={farmProjects}
                    user={user}
                    completedMissionIds={currentUserProgress.completedMissionIds}
                    onCompleteMission={handleCompleteMission}
                    onUploadPortfolio={(id) => {
                        const m = findContentById(id);
                        if(m) { setActivePortfolioItem(m); setIsPortfolioOpen(true); }
                    }}
                    onUpdateMissions={handleUpdateMissions}
                    onUpdateArt={handleUpdateArt}
                    onUpdateScience={handleUpdateScience}
                    onUpdateFarm={handleUpdateFarm}
                />
            )}
            
            {/* Private Variants of Content Pages */}
            {currentView === ViewState.FARM_PROJECTS && (
                // @ts-ignore
                <FarmProjects onNavigate={setCurrentView} projects={farmProjects} user={user} onUpdate={handleUpdateFarm} onComplete={handleCompleteProject} completedIds={currentUserProgress.completedProjectIds} variant="private" />
            )}
            {currentView === ViewState.ART_STUDIO && (
                // @ts-ignore
                <ArtStudio onNavigate={setCurrentView} projects={artProjects} user={user} onUpdate={handleUpdateArt} onComplete={handleCompleteProject} completedIds={currentUserProgress.completedProjectIds} variant="private" />
            )}
            {currentView === ViewState.SCIENCE_LAB && (
                // @ts-ignore
                <ScienceLab onNavigate={setCurrentView} experiments={scienceExperiments} user={user} onUpdate={handleUpdateScience} onComplete={handleCompleteProject} completedIds={currentUserProgress.completedProjectIds} variant="private" />
            )}

            {currentView === ViewState.CRYPTOGRAPHY && (
                <SpellingGame 
                    lists={SPELLING_CURRICULUM.filter(l => l.gradeLevel === ((user as Student).grade || 12))} 
                    completedIds={currentUserProgress.completedSpellingIds} 
                    onComplete={handleCompleteSpelling} 
                />
            )}
            
            {currentView === ViewState.SECURE_LINE && <SecureLine />}
            {currentView === ViewState.GADGET_LAB && <GadgetLab />}
            {currentView === ViewState.PORTFOLIO && <Portfolio />}
            {currentView === ViewState.RECRUIT_TRACKER && <RecruitTracker students={students} onSync={() => setIsSyncOpen(true)} />}
        </div>
      </main>
    </div>
  );
};
export default App;
